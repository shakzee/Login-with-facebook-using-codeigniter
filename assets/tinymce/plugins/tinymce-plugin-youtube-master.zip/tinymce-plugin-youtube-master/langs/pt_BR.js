tinymce.addI18n('pt_BR', {
    'YouTube Tooltip'   : "YouTube",
    'YouTube Title'     : "Inserir um vídeo do Youtube",
    'Youtube URL'       : 'URL do Youtube',
    'Youtube ID'        : 'http://youtu.be/xxxxxxxx or http://www.youtube.com/watch?v=xxxxxxxx',
    'width'             : 'Largura',
    'height'            : 'Altura',
    'autoplay'          : 'Tocar automaticamente',
    'Related video'     : 'Vídeos relacionados',
    'HD video'          : 'Assistir em HD',
    'cancel'            : 'Cancelar',
    'Insert'            : 'Inserir'
});
