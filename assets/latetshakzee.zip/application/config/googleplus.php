<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$config['googleplus']['application_name'] = 'shakzee';
$config['googleplus']['client_id']        = '488513742715-shohcvjcc5msvrdeslf5ep2tftirkqld.apps.googleusercontent.com';
$config['googleplus']['client_secret']    = '1icNyKVRthDNA3wJ041cxCSw';
$config['googleplus']['redirect_uri']     = 'http://www.shakzee.com/signup/';
$config['googleplus']['api_key']          = '';
$config['googleplus']['scopes']           = array();

