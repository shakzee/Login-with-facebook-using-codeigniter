<?php
class Admin extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}

	function index()
	{
		if (admin_login())
		{
			$data['title'] =  'Admin - Login | PapaGames';
			$this->load->view('admin/header/header',$data);
			$this->load->view('admin/css/css');
			$this->load->view('admin/navbar/navbartop');
			$this->load->view('admin/navbar/navbar_left');
			$this->load->view('admin/content/home');
			$this->load->view('admin/footer/footer');
			$this->load->view('admin/js/admin_extrajs');			
			$this->load->view('admin/js/js');	
		}
		else
		{
			c_flash('alert-warning','Please login first.','admin/login');
		}
		
	}



	public function login()
	{
		
		if (admin_login())
		{
			redirect('admin');
		}
		else
		{
			$data['title'] =  'Admin - Login | PapaGames';
			$this->load->view('admin/header/header',$data);
			$this->load->view('admin/css/css_l');
			$this->load->view('admin/navbar/navbar_l');
			$this->load->view('admin/content/login');
			$this->load->view('admin/footer/footer_l');
			$this->load->view('admin/js/js');			

		}
		
	}

/*	public function dd()
	{
		echo do_hash('9045CF4@l');
	}
*/
	public function checkadmin()
	{
		$data['email'] = $this->input->post('email',TRUE);
		$data['password'] = $this->input->post('password',TRUE);

		if (!empty($data['email'] || !empty($data['password'])))
		{
			$data['password'] = do_hash($data['password']);
			$check = $this->mod_admin->checkadmin($data);
			if (count($check) === 1)
			{
				$admin_session = array(
						'admin_id' =>$check[0]['id'] , 
						'admin_email' =>$check[0]['email'] , 
						'admin_create' =>$check[0]['create'] , 
						'admin_name' =>$check[0]['name'] , 
						);
				$this->session->set_userdata($admin_session);
				if (admin_id())
				{
					redirect('admin');
				}
				else
				{
					c_flash('alert-warning','Ooops something going wrong please try again.','admin/login');
				}
				
			}
			else
			{
				c_flash('alert-danger','Email OR Password Invalid.','admin/login');
			}
			
		}
		else
		{
			c_flash('alert-warning','Please login first.','admin/login');
		}
		
	}

	public function addcategories()
	{
			$data['title'] =  'Admin - Add Categories | PapaGames';
			$this->load->view('admin/header/header',$data);
			$this->load->view('admin/css/css');
			$this->load->view('admin/navbar/navbartop');
			$this->load->view('admin/navbar/navbar_left');
			$this->load->view('admin/content/addcategories');
			$this->load->view('admin/footer/footer');
			$this->load->view('admin/js/js');	
	}

	public function addcategory()
	{
		$data['c_name'] = $this->input->post('addcategory',TRUE);
		if (!empty($data['c_name']))
		{
			$data['c_created'] =  date_time();
			$checkcategroy = $this->mod_admin->checkcategroy($data);
			if ($checkcategroy->num_rows() > 0)
			{
				c_flash('alert-warning', 'This Category '. $data['c_name'] . ' Already Exist.' . ' has been successfully added.', 'admin/addcategories');
			}
			else
			{
				if (isset($_FILES['cat_dp']) && is_uploaded_file($_FILES['cat_dp']['tmp_name'])) 
				{
					$image_path = realpath(APPPATH . '../assets/images/a_category');
					$config['upload_path'] = $image_path;
					$config['allowed_types'] = 'gif|jpg|png';
					$config['max_size']	= '10000';
					$config['max_width'] = 1024;
	                $config['max_height'] = 500;
	                $config['file_name'] = random_string('alnum', 16);

					$this->load->library('upload', $config);
					if (!$this->upload->do_upload('cat_dp'))
					{
						$error = $this->upload->display_errors('<p>','</p>');

						c_flash('alert-danger',$error,'admin/addcategories');

					}
					else
					{
						$filename = $this->upload->data();
						$data['c_dp'] = $filename['file_name'];
						/*$image_path = realpath(APPPATH . '../assets/images/blogs/');
						 unlink($image_path.'/'.$old_cover);*/

					}
				}//checking image if selected.
				$add_cat = $this->mod_admin->addcategory($data);
				if ($add_cat)
				{
					c_flash('alert-success', $data['c_name'] . ' has been successfully added.', 'admin/addcategories');
				}
				else
				{
					c_flash('alert-warning', 'Oops something going wrong please try again', 'admin/addcategories');
				}
				

			}
			


		}
		else
		{
			c_flash('alert-danger','Please check required fields and try again.','admin/addcategories');
		}
		
	}

	public function addproducts()
	{
			$data['title'] =  'Admin - Add Products | PapaGames';
			$data['categories'] = $this->mod_admin->get_products();
			$this->load->view('admin/header/header',$data);
			$this->load->view('admin/css/css');
			$this->load->view('admin/navbar/navbartop');
			$this->load->view('admin/navbar/navbar_left');
			$this->load->view('admin/content/addproducts',$data);
			$this->load->view('admin/footer/footer');
			$this->load->view('admin/js/js');	
	}

	public function addproduct()
	{
		$data['cat_id'] = $this->input->post('category',TRUE);
		$data['p_name'] = $this->input->post('p_name',TRUE);
		$data['p_manufa'] = $this->input->post('p_manufa',TRUE);

		if (
				!empty($data['cat_id']) && 
				!empty($data['p_name']) && 
				!empty($data['p_manufa']) 
			)

		{
			$data['p_created'] =  date_time();
			$check_product = $this->mod_admin->check_product($data);
			if ($check_product->num_rows() > 0)
			{
				c_flash('alert-warning', 'This Product '. $data['p_name'] . ' Already Exist.', 'admin/addproducts');
			}
			else
			{
				
					$image_path = realpath(APPPATH . '../assets/images/a_product');
					$config['upload_path'] = $image_path;
					$config['allowed_types'] = 'gif|jpg|png';
					$config['max_size']	= '10000';
					$config['max_width'] = 500;
	                $config['max_height'] = 500;
	                $config['file_name'] = random_string('alnum', 16);

					$this->load->library('upload', $config);
					if (!$this->upload->do_upload('prdocut_dp'))
					{
						$error = $this->upload->display_errors('<p>','</p>');

						c_flash('alert-danger',$error,'admin/addproducts');

					}
					else
					{
						$filename = $this->upload->data();
						$data['p_dp'] = $filename['file_name'];
						/*$image_path = realpath(APPPATH . '../assets/images/blogs/');
						 unlink($image_path.'/'.$old_cover);*/
							$add_product = $this->mod_admin->add_product($data);
							if ($add_product)
							{
								c_flash('alert-success', $data['p_name'] . ' has been successfully added.', 'admin/addproducts');
							}
							else
							{
								c_flash('alert-warning', 'Oops something going wrong please try again', 'admin/addproducts');
							}						 
					}

			}
			


		}
		else
		{
			c_flash('alert-danger','Please check required fields and try again.','admin/addproducts');
		}
		
	}

	public function categories()
	{
		if (admin_login())
		{
			$config = array();
			$config['first_link'] = FALSE;
			$config['first_tag_open'] = '<div class="first">';
			$config['first_tag_close'] = '</div>';
			$config['last_link'] = FALSE;
			$config['last_tag_open'] = '<div class="last">';
			$config['last_tag_close'] = '</div>';
			$config['next_link'] = ' <i class="fa fa-angle-double-right xyz"></i> ';
			$config['next_tag_open'] = '<span class="next">';
			
			$config['next_tag_close'] = '</span>';
			$config['prev_link'] = ' <i class="fa fa-angle-double-left yzx"></i> ';
			$config['next_tag_open'] = '<span class="prev">';
			$config['next_tag_close'] = '</span>';

			$config["base_url"] = base_url() ."admin/categories";
	
			$categories = $this->mod_admin->get_all_categories();

			$config["total_rows"] = $categories->num_rows();
			$config["per_page"] = 2;//100;
			$config["uri_segment"] = 3;
			$this->load->library('pagination');
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
			$data["all_cat"] = $this->mod_admin->
			fatch_allcategory($config["per_page"], $page);

			$data["links"] = $this->pagination->create_links();
			$data['title'] =  'Admin - Add Categories | PapaGames';

			$this->load->view('admin/header/header',$data);
			$this->load->view('admin/css/css');
			$this->load->view('admin/navbar/navbartop');
			$this->load->view('admin/navbar/navbar_left');
			$this->load->view('admin/content/categories',$data);
			$this->load->view('admin/footer/footer');
			$this->load->view('admin/js/js');	
		}
		else
		{
			c_flash('alert-danger','Please check required fields and try again.','admin/addproducts');
		}
	}

	public function editcategory($value = null)
	{
		if (!empty($value))
		{
			$data['edit'] = $this->mod_admin->editcategory($value);
			if (count($data['edit']) === 1)
			{
				$data['title'] =  'Edit - ' . $data['edit'][0]['c_name'] . ' | PapaGames';
				$this->load->view('admin/header/header',$data);
				$this->load->view('admin/css/css');
				$this->load->view('admin/navbar/navbartop');
				$this->load->view('admin/navbar/navbar_left');
				$this->load->view('admin/content/editcategory',$data);
				$this->load->view('admin/footer/footer');
				$this->load->view('admin/js/js');	
			}
			else
			{
				c_flash('alert-danger','Category Not Available','admin/categories');
			}
			
		}
		else
		{
			c_flash('alert-danger','Oops something going wrong please try again..','admin/categories');
		}
		
	}


	public function editcat()
	{
		$data['c_name'] = $this->input->post('addcategory',TRUE);
		$c_id = $this->input->post('cat_id',TRUE);
		$old_pic = $this->input->post('old_pic',TRUE);


		//die();
		if (!empty($data['c_name']))
		{
			$data['c_created'] =  date_time();
			$checkcategroy = $this->mod_admin->checkcategroy($data);
			if ($checkcategroy->num_rows() > 0)
			{
				c_flash('alert-warning', 'This Category '. $data['c_name'] . ' Already Exist.' . ' has been successfully added.', 'admin/addcategories');
			}
			else
			{
				if (isset($_FILES['cat_dp']) && is_uploaded_file($_FILES['cat_dp']['tmp_name'])) 
				{
					$image_path = realpath(APPPATH . '../assets/images/a_category');
					$config['upload_path'] = $image_path;
					$config['allowed_types'] = 'gif|jpg|png';
					$config['max_size']	= '10000';
					$config['max_width'] = 1024;
	                $config['max_height'] = 1000;
	                $config['file_name'] = random_string('alnum', 16);

					$this->load->library('upload', $config);
					if (!$this->upload->do_upload('cat_dp'))
					{
						$error = $this->upload->display_errors('<p>','</p>');

						c_flash('alert-danger',$error,'admin/addcategories');

					}
					else
					{
						$filename = $this->upload->data();
						$data['c_dp'] = $filename['file_name'];
						$image_path = realpath(APPPATH . '../assets/images/a_category/');
						//var_dump(file_exists($image_path.'/'.$old_pic));
						//die();
						if (file_exists($image_path.'/'.$old_pic))
						{
							 unlink($image_path.'/'.$old_pic);
						}

					}
				}//checking image if selected.
				$add_cat = $this->mod_admin->edit_category($data,$c_id);
				if ($add_cat)
				{
					c_flash('alert-success', $data['c_name'] . ' has been successfully Edited.', 'admin/addcategories');
				}
				else
				{
					c_flash('alert-warning', 'Oops something going wrong please try again', 'admin/editcategory/'.$c_id);
				}
				

			}
			


		}
		else
		{
			c_flash('alert-danger','Please check required fields and try again.','admin/editcategory/'.$c_id);
		}
		
	}

	public function products()
	{
		if (admin_login())
		{
			$config = array();
			$config['first_link'] = FALSE;
			$config['first_tag_open'] = '<div class="first">';
			$config['first_tag_close'] = '</div>';
			$config['last_link'] = FALSE;
			$config['last_tag_open'] = '<div class="last">';
			$config['last_tag_close'] = '</div>';
			$config['next_link'] = ' <i class="fa fa-angle-double-right xyz"></i> ';
			$config['next_tag_open'] = '<span class="next">';
			
			$config['next_tag_close'] = '</span>';
			$config['prev_link'] = ' <i class="fa fa-angle-double-left yzx"></i> ';
			$config['next_tag_open'] = '<span class="prev">';
			$config['next_tag_close'] = '</span>';

			$config["base_url"] = base_url() ."admin/products";
	
			$products = $this->mod_admin->get_all_products();

			$config["total_rows"] = $products->num_rows();
			$config["per_page"] = 1;//100;
			$config["uri_segment"] = 3;
			$this->load->library('pagination');
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
			$data["all_products"] = $this->mod_admin->
			fatch_allproducts($config["per_page"], $page);

			$data["links"] = $this->pagination->create_links();
			$data['title'] =  'Admin - Products | PapaGames';

			$this->load->view('admin/header/header',$data);
			$this->load->view('admin/css/css');
			$this->load->view('admin/navbar/navbartop');
			$this->load->view('admin/navbar/navbar_left');
			$this->load->view('admin/content/products',$data);
			$this->load->view('admin/footer/footer');
			$this->load->view('admin/js/js');	

		}
		else
		{
			c_flash('alert-danger','Please check required fields and try again.','admin');
		}

	}

	public function productedit($value = null)
	{
		if (!empty($value))
		{
			$data['edit'] = $this->mod_admin->productedit($value);
			if (count($data['edit']) === 1)
			{
				$data['title'] =  'Edit - ' . $data['edit'][0]['p_name'] . ' | PapaGames';
				$data['categories'] = $this->mod_admin->get_products();
				$this->load->view('admin/header/header',$data);
				$this->load->view('admin/css/css');
				$this->load->view('admin/navbar/navbartop');
				$this->load->view('admin/navbar/navbar_left');
				$this->load->view('admin/content/productedit',$data);
				$this->load->view('admin/footer/footer');
				//$this->load->view('admin/js/admin_extrajs');
				$this->load->view('admin/js/js');
			}
			else
			{
				c_flash('alert-danger','Category Not Available','admin/categories');
			}
			
		}
		else
		{
			c_flash('alert-danger','Oops something going wrong please try again..','admin/products');
		}
		
	}


	public function editproduct()
	{
		$data['cat_id'] = $this->input->post('category',TRUE);
		$data['p_name'] = $this->input->post('p_name',TRUE);
		$data['p_manufa'] = $this->input->post('p_manufa',TRUE);

	 	$p_id = $this->input->post('p_ix',TRUE);
		$old_pic = $this->input->post('op_x',TRUE);
		//die();
		if (
				!empty($data['cat_id']) && 
				!empty($data['p_name']) && 
				!empty($data['p_manufa']) 
			)

		{
			$data['p_created'] =  date_time();
			$check_product = $this->mod_admin->check_product($data);
			if ($check_product->num_rows() > 0)
			{
				c_flash('alert-warning', 'This Product '. $data['p_name'] . ' Already Exist.', 'admin/productedit/'.$p_id);
			}
			else
			{
				
					/*$image_path = realpath(APPPATH . '../assets/images/a_product');
					$config['upload_path'] = $image_path;
					$config['allowed_types'] = 'gif|jpg|png';
					$config['max_size']	= '10000';
					$config['max_width'] = 100;
	                $config['max_height'] = 100;
	                $config['file_name'] = random_string('alnum', 16);*/

				if (isset($_FILES['prdocut_dp']) && is_uploaded_file($_FILES['prdocut_dp']['tmp_name'])) 
				{
					$image_path = realpath(APPPATH . '../assets/images/a_product');
					$config['upload_path'] = $image_path;
					$config['allowed_types'] = 'gif|jpg|png';
					$config['max_size']	= '10000';
					$config['max_width'] = 1024;
	                $config['max_height'] = 1000;
	                $config['file_name'] = random_string('alnum', 16);

					$this->load->library('upload', $config);
					if (!$this->upload->do_upload('prdocut_dp'))
					{
						$error = $this->upload->display_errors('<p>','</p>');

						c_flash('alert-danger',$error,'admin/products');

					}
					else
					{
						$filename = $this->upload->data();
						$data['p_dp'] = $filename['file_name'];
						$image_path = realpath(APPPATH . '../assets/images/a_product/');
						//var_dump(file_exists($image_path.'/'.$old_pic));
						//die();
						if (file_exists($image_path.'/'.$old_pic))
						{
							 unlink($image_path.'/'.$old_pic);
						}

					}
				}//checking image if selected.

					$editproduct = $this->mod_admin->editproduct($data,$p_id);
					if ($editproduct)
						{
							c_flash('alert-success', $data['p_name'] . ' has been successfully Edited.', 'admin/addproducts');
						}
						else
						{
							c_flash('alert-warning', 'Oops something going wrong please try again', 'admin/addproducts');
						}					

			}
			


		}
		else
		{
			c_flash('alert-danger','Please check required fields and try again.','admin/productedit/'.$p_id);
		}
		
	}


	public function deletecategory()
	{
		$dtext = $this->input->post('dtxt',TRUE);
		$this->input->post('di',TRUE);
		if (!empty($dtext))
		{
			 $dtext = $this->encrypt->decode($dtext);
			$sxt = $this->mod_admin->deletecategory($dtext);
			 if ($sxt)
			 {
			 	echo TRUE;
			 }
			 else
			 {
			 	echo FALSE;
			 }
			 
		}	
		else
		{
			echo  '404page';
		}
		

	}

	public function deleteproduct()
	{
		$dtext = $this->input->post('dtxt',TRUE);
		$this->input->post('di',TRUE);
		if (!empty($dtext))
		{
			$dtext = $this->encrypt->decode($dtext);
			$sxt = $this->mod_admin->deleteproduct($dtext);
			 if ($sxt)
			 {
			 	echo TRUE;
			 }
			 else
			 {
			 	echo FALSE;
			 }
			 
		}	
		else
		{
			echo  '404page';
		}
		

	}

	public function modeladd()
	{
		if (admin_login())
		{
			$data['title'] =  'Admin - Add Modal | PapaGames';
			$data['categories'] = $this->mod_admin->get_products();
			$this->load->view('admin/header/header',$data);
			$this->load->view('admin/css/css');
			$this->load->view('admin/navbar/navbartop');
			$this->load->view('admin/navbar/navbar_left');
			$this->load->view('admin/content/modeladd',$data);
			$this->load->view('admin/footer/footer');
			$this->load->view('admin/js/js');	

		}
		else
		{
			c_flash('alert-warning','Please login first.','admin/login');
		}
	}

	public function addmodel()
	{
		if (admin_login())
		{
			$data['m_name'] = $this->input->post('mo_name',TRUE);
			$data['m_display'] = $this->input->post('m_display',TRUE);
			$data['m_size'] = $this->input->post('m_size',TRUE);
			$data['m_desc'] = $this->input->post('m_desc',TRUE);
			$data['m_created'] = date_time();
			$products_id = $this->input->post('tags',TRUE);
			$data['product_id'] = $products_id[0]; 
			// /var_dump(!empty($products_id));
			//die();
			if (
				 empty($data['m_name']) || empty($data['m_display']) || 
				  empty($data['m_size']) || empty($data['m_desc']) || 
				    empty($products_id)
				)
			{
				c_flash('alert-danger','Please check required fields and try again.','admin/modeladd');

				//echo 'set ha..';
			}
			else
			{
				$check_model = $this->mod_admin->check_model($data);
				if ($check_model->num_rows() > 0)
				{
					c_flash('alert-warning', 'This Model '. $data['m_name'] . ' Already Exist.', 'admin/modeladd');
				}
				else
				{
				
					$image_path = realpath(APPPATH . '../assets/images/a_model');
					$config['upload_path'] = $image_path;
					$config['allowed_types'] = 'gif|jpg|png';
					$config['max_size']	= '10000';
					$config['max_width'] = 500;
	                $config['max_height'] = 500;
	                $config['file_name'] = random_string('alnum', 16);

					$this->load->library('upload', $config);
					if (!$this->upload->do_upload('mod_dp'))
					{
						$error = $this->upload->display_errors('<p>','</p>');

						c_flash('alert-danger',$error,'admin/modeladd');

					}
					else
					{
						$filename = $this->upload->data();
						$data['m_dp'] = $filename['file_name'];
						/*$image_path = realpath(APPPATH . '../assets/images/blogs/');
						 unlink($image_path.'/'.$old_cover);*/
							$add_product = $this->mod_admin->add_model($data);
							if ($add_product)
							{
								c_flash('alert-success', $data['p_name'] . ' has been successfully added.', 'admin/modeladd');
							}
							else
							{
								c_flash('alert-warning', 'Oops something going wrong please try again', 'admin/modeladd');
							}						 
					}

				}
			}
			

		}
		else
		{
			c_flash('alert-warning','Please login first.','admin/login');
		}
		
	}

	public function models()
	{
		if (admin_login())
		{
			$config = array();
			$config['first_link'] = FALSE;
			$config['first_tag_open'] = '<div class="first">';
			$config['first_tag_close'] = '</div>';
			$config['last_link'] = FALSE;
			$config['last_tag_open'] = '<div class="last">';
			$config['last_tag_close'] = '</div>';
			$config['next_link'] = ' <i class="fa fa-angle-double-right xyz"></i> ';
			$config['next_tag_open'] = '<span class="next">';
			
			$config['next_tag_close'] = '</span>';
			$config['prev_link'] = ' <i class="fa fa-angle-double-left yzx"></i> ';
			$config['next_tag_open'] = '<span class="prev">';
			$config['next_tag_close'] = '</span>';

			$config["base_url"] = base_url() ."admin/models";
	
			$modals = $this->mod_admin->get_all_modals();

			$config["total_rows"] = $modals->num_rows();
			$config["per_page"] = 1;//100;
			$config["uri_segment"] = 3;
			$this->load->library('pagination');
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
			$data["all_models"] = $this->mod_admin->
			fatch_all_models($config["per_page"], $page);

			$data["links"] = $this->pagination->create_links();
			$data['title'] =  'Admin - Products | PapaGames';

			$this->load->view('admin/header/header',$data);
			$this->load->view('admin/css/css');
			$this->load->view('admin/navbar/navbartop');
			$this->load->view('admin/navbar/navbar_left');
			$this->load->view('admin/content/models',$data);
			$this->load->view('admin/footer/footer');
			$this->load->view('admin/js/js');	

		}
		else
		{
			c_flash('alert-danger','Please check required fields and try again.','admin');
		}

	}

	public function editmodel($value = null)
	{
		if (!empty($value))
		{
			$data['edit'] = $this->mod_admin->model_exist($value);
			if (count($data['edit']) === 1)
			{
				$data['title'] =  'Edit - ' . $data['edit'][0]['p_name'] . ' | PapaGames';
				$data['categories'] = $this->mod_admin->get_products();
				$this->load->view('admin/header/header',$data);
				$this->load->view('admin/css/css');
				$this->load->view('admin/navbar/navbartop');
				$this->load->view('admin/navbar/navbar_left');
				$this->load->view('admin/content/editmodel',$data);
				$this->load->view('admin/footer/footer');
				//$this->load->view('admin/js/admin_extrajs');
				$this->load->view('admin/js/js');
			}
			else
			{
				c_flash('alert-danger','Category Not Available','admin/categories');
			}
			
		}
		else
		{
			c_flash('alert-danger','Oops something going wrong please try again..','admin/products');
		}
		
	}


	public function modeledit()
	{
		if (admin_login())
		{
			$data['m_name'] = $this->input->post('mo_name',TRUE);
			$data['m_display'] = $this->input->post('m_display',TRUE);
			$data['m_size'] = $this->input->post('m_size',TRUE);
			$data['m_desc'] = $this->input->post('m_desc',TRUE);
			$data['m_created'] = date_time();
			/*$products_id = $this->input->post('tags',TRUE);
			$data['product_id'] = $products_id[0];*/
			$old_pic = $this->input->post('o_mdp',TRUE); 
			$m_id = $this->input->post('xd',TRUE); 
			//var_dump(!empty($this->input->post('tags',TRUE)));
			//die();
			if (
				 empty($data['m_name']) || empty($data['m_display']) || 
				  empty($data['m_size']) || empty($data['m_desc']) 
				  // || 
				  //   empty($products_id)
				)
			{
				c_flash('alert-danger','Please check required fields and try again.','admin/editmodel/'.$m_id);

				//echo 'set ha..';
			}
			else
			{
				if (!empty($this->input->post('tags',TRUE)))
				{
					$products_id = $this->input->post('tags',TRUE);
					$data['product_id'] = $products_id[0];
				}
				//echo $data['m_desc'];
				//die();
				$check_model = $this->mod_admin->check_model($data);
				if ($check_model->num_rows() > 0)
				{
					c_flash('alert-warning', 'This Model '. $data['m_name'] . ' Already Exist.', 'admin/editmodel/'.$m_id);
				}
				else
				{
						if (isset($_FILES['mod_dp']) && is_uploaded_file($_FILES['mod_dp']['tmp_name'])) 
						{
							$image_path = realpath(APPPATH . '../assets/images/a_model');

							$config['upload_path'] = $image_path;
							$config['allowed_types'] = 'gif|jpg|png';
							$config['max_size']	= '10000';
							$config['max_width'] = 1024;
			                $config['max_height'] = 5000;
			                $config['file_name'] = random_string('alnum', 16);

							$this->load->library('upload', $config);
							if (!$this->upload->do_upload('mod_dp'))
							{
								$error = $this->upload->display_errors('<p>','</p>');

								c_flash('alert-danger',$error,'admin/editmodel/'.$m_id);

							}
							else
							{
								$filename = $this->upload->data();
								$data['m_dp'] = $filename['file_name'];
									/*$image_path = realpath(APPPATH . '../assets/images/blogs/');
								 unlink($image_path.'/'.$old_cover);*/

							}

						}//checking image if selected.

					$edit_model = $this->mod_admin->edit_model($data,$m_id);
					if ($edit_model)
					{
						c_flash('alert-success', $data['m_name'] . ' has been successfully updated.', 'admin/models');
					}
					else
					{
						c_flash('alert-warning', 'Oops something going wrong please try again', 'admin/models');
					}	


				}//database checking model else here

			}//empty else here
			

		}//session if here
		else
		{
			c_flash('alert-warning','Please login first.','admin/login');
		}
		
	}

	public function deletemodel()
	{
		$dtext = $this->input->post('dtxt',TRUE);
		$this->input->post('di',TRUE);
		if (!empty($dtext))
		{
			$dtext = $this->encrypt->decode($dtext);
			$deletemodel = $this->mod_admin->deletemodel($dtext);
			 if ($deletemodel)
			 {
			 	echo TRUE;
			 }
			 else
			 {
			 	echo FALSE;
			 }
			 
		}	
		else
		{
			echo  '404page';
		}
		

	}

	public function newspecs()
	{
		if (admin_login())
		{
			$data['title'] =  'Admin - Add Modal | PapaGames';
			$this->load->view('admin/header/header',$data);
			$this->load->view('admin/css/css');
			$this->load->view('admin/navbar/navbartop');
			$this->load->view('admin/navbar/navbar_left');
			$this->load->view('admin/content/newspecs');
			$this->load->view('admin/footer/footer');
			$this->load->view('admin/js/js');	
		}
		else
		{
			c_flash('alert-warning','Please login first.','admin/login');
		}
		
	}

	public function addspacs()
	{
		if (admin_login())
		{
			$data['sp_created'] = date_time();
			
			$data['sp_name'] = $this->input->post('sp_name',TRUE);
			$model_id = $this->input->post('tags',TRUE);
			$sp_values = $this->input->post('sp_val',TRUE);
			
			$n_sp_values = array_filter($sp_values);
			$data['model_id'] = $model_id[0];
			/*echo count($n_sp_values);
			var_dump($n_sp_values);
			var_dump(!empty($products_id));
			die();*/
			if (
				 empty($data['sp_name']) || empty($n_sp_values) || 
				    empty($model_id)
				)
			{
				c_flash('alert-danger','Please check required fields and try again.','admin/newspecs');

				//echo 'set ha..';
			}
			else
			{
				$check_spac = $this->mod_admin->check_spac($data);
				if ($check_spac->num_rows() > 0)
				{
					c_flash('alert-warning', 'This Spec '. $data['sp_name'] . ' Already Exist.', 'admin/newspecs');
				}
				else
				{
					$spac_id = $this->mod_admin->add_spac_name($data);
					if (is_numeric($spac_id))
					{
						$spac_values = array();
						foreach ($n_sp_values as $value)
						{
							$spac_values[] = array(
										'spact_id' =>$spac_id,
										'sv_values'=>$value,
										 'sv_created'=>date_time()
									);
						}
						
						$spc_value = $this->mod_admin->add_spc_values($spac_values);
						if ($spc_value)
						{
							c_flash('alert-success', 'This Spec '. $data['sp_name'] . 'has been added.', 'admin/newspecs');
						}
						else
						{
							c_flash('alert-warning', 'Values for the Spec ' . $data['sp_name'] . ' have not been added successfully. Please try again.', 'admin/newspecs');
						}
						
						//var_dump($spac_values);
					}
					else
					{
						c_flash('alert-warning', 'This spec ' . $data['sp_name'] . ' has not been added successfully. Please try again.', 'admin/newspecs');
					}

				}
			}
			

		}
		else
		{
			c_flash('alert-warning','Please login first.','admin/login');
		}
		
	}	


	public function specs()
	{
		if (admin_login())
		{
			$config = array();
			$config['first_link'] = FALSE;
			$config['first_tag_open'] = '<div class="first">';
			$config['first_tag_close'] = '</div>';
			$config['last_link'] = FALSE;
			$config['last_tag_open'] = '<div class="last">';
			$config['last_tag_close'] = '</div>';
			$config['next_link'] = ' <i class="fa fa-angle-double-right xyz"></i> ';
			$config['next_tag_open'] = '<span class="next">';
			
			$config['next_tag_close'] = '</span>';
			$config['prev_link'] = ' <i class="fa fa-angle-double-left yzx"></i> ';
			$config['next_tag_open'] = '<span class="prev">';
			$config['next_tag_close'] = '</span>';

			$config["base_url"] = base_url() ."admin/specs";
	
			$modals = $this->mod_admin->get_all_specs();

			$config["total_rows"] = $modals->num_rows();
			$config["per_page"] = 10;//100;
			$config["uri_segment"] = 3;
			$this->load->library('pagination');
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
			$data["all_specs"] = $this->mod_admin->
			fatch_all_specs($config["per_page"], $page);

			$data["links"] = $this->pagination->create_links();
			$data['title'] =  'Admin - Products | PapaGames';

			$this->load->view('admin/header/header',$data);
			$this->load->view('admin/css/css');
			$this->load->view('admin/navbar/navbartop');
			$this->load->view('admin/navbar/navbar_left');
			$this->load->view('admin/content/specs',$data);
			$this->load->view('admin/footer/footer');
			$this->load->view('admin/js/js');	

		}
		else
		{
			c_flash('alert-danger','Please check required fields and try again.','admin');
		}

	}

	public function deletespec()
	{
		$dtext = $this->input->post('dtxt',TRUE);
		$this->input->post('di',TRUE);
		if (!empty($dtext))
		{
			$dtext = $this->encrypt->decode($dtext);
			$deletespec = $this->mod_admin->deletespec($dtext);
			 if ($deletespec)
			 {
			 	echo TRUE;
			 }
			 else
			 {
			 	echo FALSE;
			 }
			 
		}	
		else
		{
			echo  '404page';
		}
		

	}


	public function editspec($value)
	{
		if (!empty($value))
		{
			$data['edit'] = $this->mod_admin->edit_spec($value);
			if (count($data['edit']) === 1)
			{
				$data['title'] =  'Edit - ' . $data['edit'][0]['sp_name'] . ' | PapaGames';
					$this->load->view('admin/header/header',$data);
					$this->load->view('admin/css/css');
					$this->load->view('admin/navbar/navbartop');
					$this->load->view('admin/navbar/navbar_left');
					$this->load->view('admin/content/editspec',$data);
					$this->load->view('admin/footer/footer');
					$this->load->view('admin/js/js');	
			}
			else
			{
				c_flash('alert-danger','Category Not Available','admin/specs');
			}
			
		}
		else
		{
			c_flash('alert-danger','Oops something going wrong please try again..','admin/specs');
		}
	}

	public function specedite()
	{
		if (admin_login())
		{


			$data['sp_name'] = $this->input->post('sp_name',TRUE);
			$model_id = $this->input->post('tags',TRUE);

			$sp_values = $this->input->post('sp_val',TRUE);

			$n_sp_values = array_filter($sp_values);

			$s_id = $this->input->post('spx',TRUE);//spec id
	        $m_id = $this->input->post('mpx',TRUE);//model id

	        if(!empty($model_id))
			{
				$data['model_id'] = $model_id[0];
				$e_data = array(
	        		'sp_name'=>$data['sp_name'],
	        		'model_id'=> $data['model_id']
	        		);
			}
			else
			{
				$e_data = array(
	        		'sp_name'=>$data['sp_name'],
	        		'model_id'=>$m_id
	        		);
			}
	        

			//echo br(1).$m_id;
			//die();
	        /*$e_data = array(
	        		'sp_name'=>$data['sp_name'],
	        		'model_id'=>$m_id
	        		);*/
			//echo count($n_sp_values);
			//var_dump($n_sp_values);
			//var_dump(!empty($products_id));
			//die();
			if (
				 empty($data['sp_name']) || empty($s_id) || 
				    empty($m_id)
				)
			{
				c_flash('alert-danger','Please check required fields and try again.','admin/newspecs');

				//echo 'set ha..';
			}
			else
			{
				$check_spac = $this->mod_admin->check_spac($e_data);
				if ($check_spac->num_rows() > 0)
				{
					c_flash('alert-warning', 'This Spec '. $data['sp_name'] . ' Already Exist.', 'admin/newspecs');
				}
				else
				{
					$edit_spac_name = $this->mod_admin->edit_spac_name($data,$s_id);
					if ($edit_spac_name)
					{
						
						if (!empty($n_sp_values))
						{
							$spac_values = array();
							foreach ($n_sp_values as $value)
							{
								$spac_values[] = array(
											'spact_id' =>$s_id,
											'sv_values'=>$value,
											 'sv_created'=>date_time()
										);
							}
							
							$spc_value = $this->mod_admin->add_spc_values($spac_values);
							if ($spc_value)
							{
								c_flash('alert-success', 'This Spec '. $data['sp_name'] . 'has been edited.', 'admin/specs');
							}
							else
							{
								c_flash('alert-warning', 'Values for the Spec ' . $data['sp_name'] . ' have not been added successfully. Please try again.', 'admin/specs');
							}

						}//checking if giving new spec values
						else
						{
							c_flash('alert-success', 'This Spec '. $data['sp_name'] . 'has been edited.', 'admin/specs');
						}
						

					}//checking if spec edited
					else
					{
						c_flash('alert-warning', 'This spec ' . $data['sp_name'] . ' has not been edited successfully. Please try again.', 'admin/specs');
					}

				}//else if already exist.
			}//else if required fields.
			

		}//checking if admin logedin
		else
		{
			c_flash('alert-warning','Please login first.','admin/login');
		}

	}

	public function specvalues()
	{
		$dtext = $this->input->post('dtxt',TRUE);
		$this->input->post('di',TRUE);
		if (!empty($dtext))
		{
			$dtext = $this->encrypt->decode($dtext);
			///die();
			$specvalues = $this->mod_admin->specvalues($dtext);
			 if ($specvalues)
			 {
			 	 echo $data = json_encode($specvalues->result_array());
			 }
			 else
			 {
			 	echo FALSE;
			 }
			 
		}	
		else
		{
			echo  '404page';
		}
	}

	public function xx($value)
	{
		$specvalues = $this->mod_admin->specvalues($value);
			 if ($specvalues)
			 {
			 	 echo $data = json_encode($specvalues->result_array());
			 }
			 else
			 {
			 	echo FALSE;
			 }
	}

	public function findproduct()
	{
		if (empty($this->input->post('idd',TRUE)))
		{
			fc_flash('alert-warning', 'Oops something going wrong please try again', 'admin/addproducts');
		}
		else
		{
			  $name = $this->input->post('idd',TRUE);
			  $pname = $this->mod_admin->get_product_name($name);
			  
			   echo $data = json_encode($pname->result_array());
				//echo count($data);
			// echo   gettype($data);
			//json_encode($gettags);
		}		
	}
	public function findmodel()
	{
		if (empty($this->input->post('idd',TRUE)))
		{
			fc_flash('alert-warning', 'Oops something going wrong please try again', 'admin/addproducts');
		}
		else
		{
			  $name = $this->input->post('idd',TRUE);
			  $pname = $this->mod_admin->get_model_name($name);
			  
			   echo $data = json_encode($pname->result_array());
				//echo count($data);
			// echo   gettype($data);
			//json_encode($gettags);
		}		
	}
	public function signout()
	{
		if (admin_login())
		{
			$this->session->sess_destroy();
			redirect('home');
		}
		else
		{
			redirect('home');
		}
		
	}

	public function test()
	{
		//echo 'working.';

		c_flash('alert-danger','hellow','admin/login');
	}

}//class ends here

