<?php

class Aboutus extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}

	public function index()
	{

		
		$hdata['title'] = "Shakzee";
		$this->load->view('home/headfoot/header',$hdata);
		$this->load->view('home/headfoot/css');
		$this->load->view('home/navbar');
		$this->load->view('about/aboutus');
		$this->load->view('home/headfoot/footer');
		$this->load->view('home/headfoot/js');


	}

}