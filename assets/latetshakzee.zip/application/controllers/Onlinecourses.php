<?php
class Onlinecourses extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}


	function index(){
		$config = array();
		$config['first_link'] = FALSE;
		$config['first_tag_open'] = '<div class="first">';
		$config['first_tag_close'] = '</div>';
		$config['last_link'] = FALSE;
		$config['last_tag_open'] = '<div class="last">';
		$config['last_tag_close'] = '</div>';
		$config['next_link'] = ' Next ';
		$config['next_tag_open'] = '<span class="next">';
		$config['next_tag_close'] = '</span>';
		$config['prev_link'] = ' previous ';
		$config['prev_tag_open'] = '<span class="prev">';
		$config['next_tag_close'] = '</span>'; 
	    $config["base_url"] = base_url().'onlinecourses';
		
		$tot = $this->mod_onlinecourses->all_courses();
	 	$config["total_rows"] = $tot->num_rows();
		$config["per_page"] = 20;
	    $config["uri_segment"] = 2;
		$this->pagination->initialize($config);
		$page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
		$data["allcoures"] = $this->mod_onlinecourses->
		fetch_al_lcourses($config["per_page"], $page);
		$data["links"] = $this->pagination->create_links();
		$data['title'] = "Courses | shakzee";

		$data['description'] = 'Watch hundreds of free educational video tutorials in urdu langauge on computer programming, web development, web design, frameworks and more';
		$data['keywords'] = 'free, educational, videos, tutorials,shaxee,tutorial in hindi, shakzee, programming, shehzad ahmed, learn, css, php,codeigniter tutorial,bootstrap2,twitter bootstrap,bootstrap tutorial,bootstrap in urdu,urdu,codeigniter in urdu, html5, html, tutorial, mysql,jquery in urdu, beginner, introduction, ajax, jquery tutorial, source code,jquery'; 
		$data['author'] = 'Shehzad Ahmed';


		$this->load->view('home/headfoot/header',$data);
		//echo meta($data['meta']);
		$this->load->view('home/headfoot/css');
		$this->load->view('home/navbar');
		$this->load->view('onlinecourses/allcourses',$data);
		$this->load->view('home/headfoot/footer');
		$this->load->view('home/headfoot/js');

	}

	public function detail($course_id = null,$slug = null)
	{
		if (empty($course_id))
		{
			c_flash('alert-warning','Please select a course to view detail.','onlinecourses');
		}
		else
		{
			$data['course'] = $this->mod_onlinecourses->check_course($course_id);
			if (count($data['course']) == 1)
			{
				if($slug === '' || empty($slug))
				{
					$slug = url_title($data['course'][0]['uc_coursename'],'dash', true);
					redirect('onlinecourses/detail/'. $course_id . '/' . $slug);   
				}//if slug
				else
				{
					add_pro_course_view($course_id,get_user_ip());//adding user ip and course +1
					$data['rel_pro_courses'] = $this->mod_onlinecourses->related_pro_courses($data['course'][0]['uc_id']);
					//die();
					//$data['all_videos'] = $this->mod_courses->all_videos($data['course'][0]['c_id']);
					$title =  'Online course '.$data['course'][0]['uc_coursename'].' | '. $data['course'][0]['uc_level'] . ' | shakzee';
	 				$data['title'] = $title;
					$data['description'] = strip_tags($data['course'][0]['uc_detail']);
					$data['keywords'] =  'Online course '. $data['course'][0]['uc_coursename'] . ','. $data['course'][0]['uc_coursename'] .  ' ' . $data['course'][0]['uc_level'];
					$data['author'] = $data['course'][0]['fname']. ' ' .$data['course'][0]['lname'] ;
					$data['og_site_name'] = "shakzee";
					$data['og_type'] = "article";
					$data['og_title'] = $title;
					$data['og_url'] = current_url();
									//$data['og_image'] = base_url('assets/images/share.png'); 
					$data['og_description'] = word_limiter(strip_tags($data['course'][0]['uc_detail']),100);
					$data['og_image_c'] = base_url('assets/images/p_courses/'.$data['course'][0]['uc_cover']); 
					$data['og_image_type'] = "image/jpeg";
	 
					$this->load->view('home/headfoot/header',$data);
					$this->load->view('home/headfoot/css');
					$this->load->view('home/navbar');
					$this->load->view('onlinecourses/view_pro_course',$data);
					$this->load->view('home/headfoot/footer');
					$this->load->view('home/headfoot/syntaxjs');				
					$this->load->view('home/headfoot/js');					
					
				}
			}
			else
			{
				c_flash('alert-warning','This Course available only for Advance And Pro users, Please upgrade your account to view this course.','courses');
			}
		}


	}//function ends here


}//class ends here