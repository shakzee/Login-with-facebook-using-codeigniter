<?php
class Contact extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}
	public function index()
	{

		$hdata['title'] = "Contact Us | shakzee";
		//$this->mod->contactus->get_courses();
		$this->load->view('home/headfoot/header',$hdata);
		$this->load->view('home/headfoot/css');
		$this->load->view('home/navbar');
		$this->load->view('contact/contact');
		$this->load->view('home/headfoot/footer');
		$this->load->view('home/headfoot/js');

	}

	public function submitquery()
	{
		if (is_logedin())
		{
			$data['m_title'] = $this->input->post('title',TRUE);
			$data['message'] = $this->input->post('message',TRUE);
			$data['user_id'] = user_id();
			$data['created'] = date_time();
			if (empty($data['m_title']) || empty($data['message']))
			{
				c_flash('alert-success','please check required fields and try again','login');
			}
			else
			{
				$submit_query = $this->mod_contactus->submitquery($data);
				if ($submit_query)
				{
					c_flash('alert-success','Your message has been successfully received, we will contact you as soon as possible.','login');
				}
				else
				{
					c_flash('alert-success','please check required fields and try again','login');
				}

			}
			
			
		}
		else
		{
			$data['m_title'] = $this->input->post('title',TRUE);
			$data['message'] = $this->input->post('message',TRUE);
			$data['m_title'] = $this->input->post('title',TRUE);
			$data['message'] = $this->input->post('message',TRUE);
			$data['m_title'] = $this->input->post('title',TRUE);
			$data['message'] = $this->input->post('message',TRUE);

			if (
				empty($data['m_title']) || empty($data['m_title']) || 
				empty($data['m_title']) || empty($data['m_title']) || 
				empty($data['m_title']) || empty($data['m_title'])  
				)
			{

			}
			else
			{

			}
			
		}
		
	}

}//calss ends here