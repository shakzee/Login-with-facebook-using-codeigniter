<?php
class Home extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->clear_cache();
	}

	function index()
	{
		//var_dump($data['course_nav']);
		//die();
		//$data['home_course'] = $this->mod_home->get_home_course(1);
		$course = array(14,3,13);
		$data['course_home'] = $this->mod_home->corses_for_nav($course);		
		$data['pro_courses'] = $this->mod_home->pro_courses(6);
		$data['title'] = "Home | shakzee";
		$this->load->view('home/headfoot/header',$data);
		$this->load->view('home/headfoot/css');
		$this->load->view('home/navbar');
		$this->load->view('home/home',$data);
		$this->load->view('home/headfoot/footer');
		$this->load->view('home/headfoot/js');

	}
	function clear_cache()
    {
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
    }

}//class ends here