<?php
class User extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->clear_cache();
		//$this->clear_cookies();
	}

	function index()
	{
		if (is_logedin())
		{
			if (!is_teacher())
			{
				$data['title'] =  'Dashboar | shakzee';
				$this->load->view('user/header/header',$data);
				$this->load->view('user/css/css');
				$this->load->view('user/navbar/navbartop');
				$this->load->view('user/navbar/navbar_left');
				$this->load->view('user/content/home');
				$this->load->view('user/footer/footer');
				$this->load->view('user/js/admin_extrajs');			
				$this->load->view('user/js/js');	

			}
			else
			{
				c_flash('alert-warning','You are a teacher please check your Dashboar.','pagenotfound');
			}
			
		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','login');
		}
		
	}


	public function logout()
	{
		if (is_logedin())
		{
			$this->session->sess_destroy();
			$this->clear_cache();
			$this->clear_cookies();
			redirect(site_url());
		}
		else
		{	
			$this->clear_cache();
			//$this->des_session->nocache();			
			redirect(site_url());
		}
	}
	function clear_cookies()
	{
			//$this->des_session->nocache();
			if (isset($_SERVER['HTTP_COOKIE'])) {
				$cookies = explode(';', $_SERVER['HTTP_COOKIE']);
				foreach($cookies as $cookie) {
					$parts = explode('=', $cookie);
					$name = trim($parts[0]);
					setcookie($name, '', time()-1000);
					setcookie($name, '', time()-1000, '/');
				}
			}
		
	}
	function clear_cache()
    {
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
    }

	public function recover($value = null)
	{
		if (empty($value))
		{
			c_flash('alert-warning','Oops something went wrong please try again.','login');
		}
		else
		{
			$data['link'] = $value;
			$data['ch_link'] = $this->mod_registration->check_get($data['link']);
			if(count($data['ch_link']) == 1)
			{
				$data['title'] = "Recover Password | Shakzee";
				$this->load->view('home/headfoot/header',$data);
				$this->load->view('home/headfoot/css');
				$this->load->view('home/navbar');
				$this->load->view('registration/recover',$data);
				$this->load->view('home/headfoot/footer');
				$this->load->view('home/headfoot/js');							
			}
			else
			{
				c_flash('alert-warning','The link is expired or check your email and try again','login');
			}
			
		}
		
	}//function ends here

	public function resetpass()
	{
		  $data['password'] = $this->input->post('password',TRUE);
		  $cnpass = $this->input->post('cnpassword',TRUE);
		  $data['confirm_pass'] = $this->input->post('xp3',TRUE);//this is link
		//echo 'ok ha..';
		//die();
		if (
				empty($data['password']) || empty($data['confirm_pass']) ||
				empty($cnpass)
			)
		{
			c_flash('alert-warning','Please check required fields and try again.','login');
		}
		else
		{	
			$data['confirm_pass'] = $this->encrypt->decode($data['confirm_pass']);
			if ($data['password'] != $cnpass)
			{
				c_flash('alert-warning','Password not matched please your password and try again.','user/recover/'.$data['confirm_pass']);
			}
			else
			{
				$data['password'] = do_hash($data['password']);
				$resetpass = $this->mod_registration->resetpass($data);
				if ($resetpass)
				{
					//echo 'set hgya..';
					c_flash('alert-success','Your password has been updated please login now.','login');
				}
				else
				{
					//echo 'set nahen hua..';
					c_flash('alert-warning','Oops something going wrong we can\'t update your password please try again.','user/recover/'.$data['confirm_pass']);
				}
				
			}
			
		}
		
	}

	public function lastnoti()
	{
		if (is_logedin())
		{
			$data['user_id'] = user_id();
			$data['last_noti_date'] = date_time(); 
			//var_dump($data);
			//die();
			$uery = $this->mod_user->lastnoti($data);
			$this->session->set_userdata('last_noti_date',$data['last_noti_date']);
			echo $uery;
		}
		else
		{
			echo 'Ooops something going wrong.';
		}
		
	}


	public function settings()
	{
		if (is_logedin())
		{
			if (!is_teacher())
			{
				$data['title'] =  'settings | shakzee';
				$this->load->view('user/header/header',$data);
				$this->load->view('user/css/css');
				//$this->load->view('user/css/datepicker');
				$this->load->view('user/navbar/navbartop');
				$this->load->view('user/navbar/navbar_left');
				$this->load->view('user/content/home');
				$this->load->view('user/footer/footer');
				//$this->load->view('user/js/datepickerjs');			
				$this->load->view('user/js/js');	

			}
			else
			{
				c_flash('alert-warning','You are a teacher please check your Dashboar..','pagenotfound');
			}
			
		}
		else
		{
			c_flash('alert-warning','Please login first.','login');
		}
		
	}


	public function updatename()
	{
		if (!$this->input->is_ajax_request())
		{
			c_flash('alert-warning','Something went wrong please try again.','pagenotfound');
		}
		else
		{
			$data['fname'] =	$this->input->post('fname_7',TRUE);
			$data['lname'] = $this->input->post('lname_7',TRUE);
			$user_id = user_id();
			//var_dump($data);
			//die();
			if ($this->session->userdata('social') == 1)
			{
					$data['error'] = 'You can\'t update your name because you logedin from ' . $this->session->userdata('social_network');
					echo json_encode($data);
			}
			else
			{
				if (!empty($data['fname']) ||
					!empty($data['lname'])
				)
				{
					$nupdate = $this->mod_user->updatuser($user_id,$data);
					if ($nupdate)
					{
						$this->session->set_userdata('fname',$data['fname']);
						$this->session->set_userdata('lname',$data['lname']);
						$data['return'] = 'true';
						echo json_encode($data);
					}
					else
					{
						$data['return'] = 'false'; 
						echo json_encode($data);
					}
					
				}
				else
				{
					$data['error'] = 'Please check required fields and try again.';
					echo json_encode($data);
				}				
			}
			
			
		}
		
	}



	public function updatemobile()
	{
		if (!$this->input->is_ajax_request())
		{
			c_flash('alert-warning','Something went wrong please try again.','pagenotfound');
		}
		else
		{
			$data['u_mobile'] =	$this->input->post('mb_7',TRUE);
			$user_id = user_id();
			//var_dump($data);
			//die();
			if (
					!empty($data['u_mobile'])
				)
			{
				$updatuser = $this->mod_user->updatuser($user_id,$data);
				if ($updatuser)
				{
					$this->session->set_userdata('u_mobile',$data['u_mobile']);
					$data['return'] = 'true';
					echo json_encode($data);
				}
				else
				{
					$data['return'] = 'false'; 
					echo json_encode($data);
				}
				
			}
			else
			{
				$data['error'] = 'Please check required fields and try again.';
				echo json_encode($data);
			}
			
		}
		
	}

	public function updategender()
	{
		if (!$this->input->is_ajax_request())
		{
			c_flash('alert-warning','Something went wrong please try again.','pagenotfound');
		}
		else
		{
			$data['u_gender'] =	$this->input->post('gn_7',TRUE);
			$user_id = user_id();
			//var_dump($data);
			//die();
			if (
					!empty($data['u_gender'])
				)
			{
				$updatuser = $this->mod_user->updatuser($user_id,$data);
				if ($updatuser)
				{
					$this->session->set_userdata('u_gender',$data['u_gender']);
					$data['return'] = 'true';
					echo json_encode($data);
				}
				else
				{
					$data['return'] = 'false'; 
					echo json_encode($data);
				}
				
			}
			else
			{
				$data['error'] = 'Please check required fields and try again.';
				echo json_encode($data);
			}
			
		}
		
	}
	public function updatedadd()
	{
		if (!$this->input->is_ajax_request())
		{
			c_flash('alert-warning','Something went wrong please try again.','pagenotfound');
		}
		else
		{
			$data['u_address'] =	$this->input->post('ad_7',TRUE);
			$user_id = user_id();
			//var_dump($data);
			//die();
			if (
					!empty($data['u_address'])
				)
			{
				$updatuser = $this->mod_user->updatuser($user_id,$data);
				if ($updatuser)
				{
					$this->session->set_userdata('u_address',$data['u_address']);
					$data['return'] = 'true';
					echo json_encode($data);
				}
				else
				{
					$data['return'] = 'false'; 
					echo json_encode($data);
				}
				
			}
			else
			{
				$data['error'] = 'Please check required fields and try again.';
				echo json_encode($data);
			}
			
		}
		
	}


	public function updatedob()
	{
		if (!$this->input->is_ajax_request())
		{
			c_flash('alert-warning','Something went wrong please try again.','pagenotfound');
		}
		else
		{
			$date =	$this->input->post('date',TRUE);
			$month = $this->input->post('month',TRUE);
			$year = $this->input->post('year',TRUE);
			$time = mktime(0, 0, 0, $month, $date, $year);
			$data['u_dob'] = date("Y-m-d",$time);

			$user_id = user_id();
			//var_dump($data);
			//die();
			if (	!empty($date) ||
					!empty($month) || !empty($year)
				)
			{
				$nupdate = $this->mod_user->updatuser($user_id,$data);
				if ($nupdate)
				{
					$this->session->set_userdata('u_dob',$data['u_dob']);
					$data['return'] = 'true';
					echo json_encode($data);
				}
				else
				{
					$data['return'] = 'false'; 
					echo json_encode($data);
				}
				
			}
			else
			{
				$data['error'] = 'Please check required fields and try again.';
				echo json_encode($data);
			}
			
		}
		
	}

	public function changedp()
	{
		if (is_logedin())
		{
			$user_id = user_id();
			$old_pic = $this->input->post('dp',TRUE);
			$old_pic = $this->encrypt->decode($old_pic);
			$image_path = realpath(APPPATH . '../assets/images/users');
			if ($this->session->userdata('social') == 1)
			{
					$error = 'You can\'t update your name because you logedin from ' . $this->session->userdata('social_network');
					c_flash('alert-warning',$error,'user/settings');
			}
			else
			{
			if (isset($_FILES['ndp']) && is_uploaded_file($_FILES['ndp']['tmp_name'])) 
				{
					$image_path = realpath(APPPATH . '../assets/images/users');
					$config['upload_path'] = $image_path;
					$config['allowed_types'] = 'gif|jpg|png';
					//$config['max_size']	= '10000';
					//$config['max_width'] = 1024;
	                //$config['max_height'] = 1000;
	                $config['file_name'] = random_string('alnum', 16);

					$this->load->library('upload', $config);
					if (!$this->upload->do_upload('ndp'))
					{
						$error = $this->upload->display_errors('<p>','</p>');

						c_flash('alert-danger',$error,'user/settings');

					}
					else
					{
						$filename = $this->upload->data();
						$data['u_dp'] = $filename['file_name'];
						$image_path = realpath(APPPATH . '../assets/images/users/');
						//var_dump(file_exists($image_path.'/'.$old_pic));
						//die();
							switch ($old_pic)
							{
									case 'male.jpg':	
										$old_pic='xyz';
										break;
									case 'female.jpg':
										$old_pic='xyz';
										break;
									
							}	
							
								if (file_exists($image_path.'/'.$old_pic))
								{
									 unlink($image_path.'/'.$old_pic);
								}
						$nupdate = $this->mod_user->updatuser($user_id,$data);
						if ($nupdate) 
						{
							$this->session->set_userdata('u_dp',$data['u_dp']);
							c_flash('alert-success','Your profile pic has been succssfully updated','user/settings');
						}
						else
						{
							c_flash('alert-success','We can\'t update your profile right now please try again','user/settings');
						}
						
					}
				}
				else
				{
					c_flash('alert-danger','Please select Your profile pic','user/settings');
				}//checking image if selected.			

			}
					
		}
		else
		{
			c_flash('alert-warning','Please login.','login');
		}
		
	}
}//class ends here