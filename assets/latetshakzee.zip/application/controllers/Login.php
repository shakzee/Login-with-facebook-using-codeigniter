<?php
class Login extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->clear_cache();

	}

	function index()
	{
		if (is_logedin())
		{
			switch ($this->session->userdata('teacher')) 
			{
				case 0:
					redirect('user');
				break;
				case 1:
					redirect('tutor');
					break;
			}	
			
		}
		else
		{
			include_once APPPATH."libraries/facebook-api-php-codexworld/facebook.php";
			//echo 'working...	';
			//die();
			if(is_logedin())
			{
				redirect(site_url());
			}//checking if user already  logedin 
			
			$appId = '425107520978297';
			$appSecret = '394cc5a3c4f11a25361d3f753fe2c95a';
			$redirectUrl = base_url() . 'signup/';
			$fbPermissions = 'email';
			$facebook = new Facebook(array(
			  'appId'  => $appId,
			  'secret' => $appSecret
			
			));
			$fbuser = $facebook->getUser();
			if ($fbuser) {
				$userProfile = $facebook->api('/me?fields=id,first_name,last_name,email,gender,locale,picture');
				//echo $newdata = $userProfile['picture']['data'];
				//var_dump($userProfile['picture']['data']);
				//echo image($userProfile['url']);
				//var_dump($userProfile);
				//echo $userProfile['picture'];
				$fbdata['social_network'] = 'facebook';
				$fbdata['fname'] = $userProfile['first_name'];
				$fbdata['lname'] = $userProfile['last_name'];
				$fbdata['email'] = $userProfile['email'];
				$fbdata['u_gender'] = $userProfile['gender'];
				$fbdata['social_dp'] = $userProfile['picture']['data']['url'];
				$fbdata['teacher'] = 0 ;
				$fbdata['u_status'] = 1 ;
				$fbdata['social'] = 1 ;
				$fbdata['u_created'] = date('Y-m-d H:i:s');
				$fbdata['u_type'] = 1;
				
				$check_email = $this->mod_registration->check_email($fbdata);
				//var_dump($check_email);
				//die();
				if(!empty($check_email) && count($check_email == 1))
				{
					//var_dump($check_email);
					//die();
					
					if($check_email[0]['social'] == 1)
					{
						switch ($check_email[0]['social_network']) {
							case 'facebook':						
								update_fb($fbdata);
								break;
							case 'googleplus':						
								c_flash('alert-warning','Please login with your '. $check_email[0]['social_network'] . ' account.' ,'signup');
								break;
							}//switch ends her
						
					}
					else
					{
						c_flash('alert-warning','Please login with this ' . $check_email[0]['email'] . 'email.' ,'signup');
						
					}
				}
				else
				{
					insert_fb($fbdata);
				}

					/*echo br(2);
					var_dump($userProfile);
					echo br(5);
					var_dump($userProfile['picture']['data']['url']);
					echo img($userProfile['picture']['data']['url']);
					*/
				
				}
			else
			{
				$fbuser = '';
				$data['fburl'] = $facebook->getLoginUrl(array('redirect_uri'=>$redirectUrl,'scope'=>$fbPermissions));
			}/*facebook api ends here*/
			
			if (isset($_GET['code']))//google plus api starts here
			{
				$this->googleplus->getAuthenticate();
				$googldata = $this->googleplus->getUserInfo();
				/*var_dump($googldata);
				die();*/
				$gdata['social_network'] = 'googleplus';
				$gdata['fname'] = $googldata['given_name'];
				$gdata['lname'] = $googldata['family_name'];
				$gdata['email'] = $googldata['email'];
				//$gdata['u_gender'] = $googldata['gender'];
				$gdata['social_dp'] = $googldata['picture'];
				$gdata['teacher'] = 0 ;
				$gdata['u_status'] = 1 ;
				$gdata['social'] = 1 ;
				$gdata['u_created'] = date('Y-m-d H:i:s');
				$gdata['u_type'] = 1;
				$gdata['oauth_uid'] =  $googldata['id'];
				
				$check_email = $this->mod_registration->check_email($gdata);
				//var_dump($check_email);
				if(!empty($check_email) && count($check_email == 1))
				{
					if($check_email[0]['social'] == 1)
					{
						switch ($check_email[0]['social_network']) {
							case 'facebook':
									c_flash('alert-warning','Please login with your '. $check_email[0]['social_network'] . ' account.' ,'signup');
								break;
							case 'googleplus':						
								update_googleplus($gdata);
								break;
							}//switch ends her
						
					}
					else
					{
						//echo 'hereis..';
						//die();
						c_flash('alert-warning','Please login with this ' . $check_email[0]['email'] . ' email.' ,'signup');
						
					}
				}
				else
				{
					insert_googleplus($gdata);
				}

				//var_dump($gdata);
			}
			
			$data['g_login_url'] = $this->googleplus->loginURL();
			$data['title'] = "Login | shakzee";
			$this->load->view('home/headfoot/header',$data);
			$this->load->view('home/headfoot/css');
			$this->load->view('home/navbar');
			$this->load->view('registration/login',$data);
			$this->load->view('home/headfoot/footer');
			$this->load->view('home/headfoot/js');
		}
		
	}


	public function checkuser()
	{
		$data['email'] = $this->input->post('email',TRUE);
		$data['password'] = do_hash($this->input->post('password',TRUE));
		if (
				empty($data['email']) || empty($data['password'])
			)
		{
			c_flash('alert-success','please check required fields and try again','login');
		}
		else
		{
			$check_uer = $this->mod_registration->check_email($data);
			if (count($check_uer) > 0)
			{
				if ($check_uer[0]['u_status'] == 1)
				{
					if ($check_uer[0]['social'] == 1)
					{
						c_flash('alert-danger','Please login with your <strong>' . $check_uer[0]['social_network'] . '</strong> account.','login');						
					}
					else
					{
						if ($check_uer[0]['password'] === $data['password'])
						{
							$user_session = array(
								'u_id' =>$check_uer[0]['u_id'],
								'email'=>$check_uer[0]['email'],
								'fname'=>$check_uer[0]['fname'],
								'lname'=>$check_uer[0]['lname'],
								'u_dp'=>$check_uer[0]['u_dp'],
								'u_address'=>$check_uer[0]['u_address'],
								'u_mobile'=>$check_uer[0]['u_mobile'],
								'u_dob'=>$check_uer[0]['u_dob'],
								'u_gender'=>$check_uer[0]['u_gender'],
								'last_login'=>$check_uer[0]['last_login'],
								'teacher'=>$check_uer[0]['teacher'],
								'u_type'=>$check_uer[0]['u_type'],
								'u_created'=>$check_uer[0]['u_created'],
								'u_dob'=>$check_uer[0]['u_dob'],
								'social'=>$check_uer[0]['social'],
								'social_dp'=>$check_uer[0]['social_dp'],
								'social_network'=>$check_uer[0]['social_network'],
								'oauth_uid'=>$check_uer[0]['oauth_uid'],
								'last_noti_date'=>$check_uer[0]['last_noti_date'],
							 );
							$this->session->set_userdata($user_session);
							redirect('home');
							/*switch ($check_uer[0]['teacher']) {
								case 0:
								last_login($check_uer[0]['u_id']);
									redirect('user');
									break;
								case 1:
								last_login($check_uer[0]['u_id']);
									redirect('tutor');
									break;
							}//switch ends here*/							

						}//if password matched.
						else
						{
							c_flash('alert-danger','Your password is invalid, please check your password and try again.','login');
						}//else invalid password
						
					}//else not social

				}//if user active
				else if($check_uer[0]['social'] == 2)
				{
					c_flash('alert-danger','Your account has been suspended, please contact us.','login');					
				}//if user's account suspended
				else
				{
					c_flash('alert-danger','Your account is not activated, please activate you account.','login');					
				}//else user not activated yet.
				
			}
			else
			{
				c_flash('alert-danger','This email '. $data['email'] . ' is not exist please '. anchor('signup','Create Account'),'login');					
			}
			

			/*$data['password'] = do_hash($data['password']);
			$check_user = $this->mod_registration->check_user_login($data);
			if (count($check_user) === 1)
			{

				$user_session = array(
								'u_id' =>$check_user[0]['u_id'],
								'email'=>$check_user[0]['email'],
								'fname'=>$check_user[0]['fname'],
								'lname'=>$check_user[0]['lname'],
								'u_dp'=>$check_user[0]['u_dp'],
								'u_address'=>$check_user[0]['u_address'],
								'u_mobile'=>$check_user[0]['u_mobile'],
								'u_dob'=>$check_user[0]['u_dob'],
								'u_gender'=>$check_user[0]['u_gender'],
								'last_login'=>$check_user[0]['last_login'],
								'teacher'=>$check_user[0]['teacher'],
								'u_type'=>$check_user[0]['u_type'],
								'u_created'=>$check_user[0]['u_created'],
								'u_dob'=>$check_user[0]['u_dob']
							 );
						$this->session->set_userdata($user_session);
				switch ($check_user[0]['teacher']) {
					case 0:
					last_login($check_user[0]['u_id']);
						redirect('user');
						break;
					case 1:
					last_login($check_user[0]['u_id']);
						redirect('tutor');
						break;
				}
				
				
			}
			else if(!empty($check_user) && $check_user[0]['teacher'] == 2)
			{
				c_flash('alert-danger','Your account has been suspended because of seome reason. pelase contact us.','login');
			}
			else
			{
				c_flash('alert-danger','Your email OR password invalid please try again.','login');
			}*/
			
		}//else empty here
		

	}//function ends here


	public function forgotpass()
	{
		$data['email'] = $this->input->post('fpin_7',TRUE);
		if (empty($data['email']))
		{
			//echo $data['email'];
			echo 'redirect here';
		}
		else
		{
			$cfpass = $this->mod_registration->check_email($data);
			if (count($cfpass) == 1)
			{
				if ($cfpass[0]['social'] == 1)
				{
					echo 'Plase login with your <strong>'. $cfpass[0]['social_network'] . ' </strong>  account.';
				}
				else
				{
					$data['confirm_pass'] = random_string('alnum', 20); 
					$data['fname'] = $cfpass[0]['fname'];
					$send_fpass = $this->mod_registration->send_fpass($data);
					if ($send_fpass)
					{
						if ($this->sendconfirmpass($data))
						{
							echo 'We have just sent a link to your email address please check your <strong> inbox </strong> or <strong> junk </strong> folder to reset your account.';
						}
						else
						{
							echo 'We can\'t send you a link right now please try again.';
						}
						
					}
					else
					{
						echo 'Oops something went wrong please try again.';
					}
					
				}
				
			}
			else
			{
				echo 'Email not found please <strong>' . anchor('signup','Create an ccount.') . '<strong>';
			}
			
		}//main else here
		
	}//function end shere	

	function clear_cache()
    {
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
    }

    public function sendconfirmpass($data)
	{
		$config = array(
		'useragent' => 'CodeIgniter', 
		'protocol' => 'mail', 
		'mailpath' => '/usr/sbin/sendmail',
		'smtp_host' => 'localhost',
		'smtp_user' => 'info@poetnpoetry.com',
		'smtp_pass' => 'Talhatalib171$',
		'smtp_port' => 25,
		'smtp_timeout' => 55,
		'wordwrap' => TRUE,
		'wrapchars' => 76,
		'mailtype' => 'html',
		'charset' => 'utf-8',
		'validate' => FALSE,
		'priority' => 3,
		'crlf' => "\r\n",
		'newline' => "\r\n",
		'bcc_batch_mode' => FALSE,
		'bcc_batch_size' => 200, 
		);

		$messg = '<strong>'.$data['fname'].'</strong><a href="'.site_url('user/recover/'.$data['confirm_pass']).'">Activation link</a>';
		 // $this->load->view("emails/invite",$data,TRUE);//useremail
		//$mymessage;
		
		$this->load->library('email', $config); 		
		$this->email->set_newline("\r\n");
		$this->email->from('info@poetnpoetry.com','Shakzee'); 
		$this->email->to($data['email']);// change it to yours
		$this->email->subject('Reset Password');
		$this->email->message($messg);
		$this->email->set_mailtype('html');
		//return $this->email->send();
		
		if($this->email->send())
		{    
			return TRUE;
		}	
		else
		{
			return FALSE;
		}
	}

}//class ends here


