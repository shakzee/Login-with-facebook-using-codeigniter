<?php
class Blogs extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}
	public function index()
	{

		$config = array();
		$config['full_tag_open'] = '<ul class="pagination gmpg">';
		$config['full_tag_close'] = '</ul>';
		$config['first_link'] = FALSE;
		$config['last_link'] = FALSE;
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';

		$config['next_link'] = 'Next';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
										
		$config['prev_link'] = 'Prev';
		$config['prev_tag_open'] = '<li class="prev">';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>'; 
		$config["base_url"] = base_url().'blogs';
		$q_sortas = null;
		
		
		$tot = $this->mod_blogs->get_all_blogs();
	 	$config["total_rows"] = $tot->num_rows();
		$config["per_page"] = 2;
	    $config["uri_segment"] = 2;

	    $this->load->library('pagination');
		$this->pagination->initialize($config);
		$page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
		$data["allblogs"] = $this->mod_blogs->
		fatch_all_blogs($config["per_page"], $page);
		$data["links"] = $this->pagination->create_links();
		$data['title'] = 'Blogs';
		$data['b_categories'] = $this->mod_blogs->get_blog_categories();
		$data['mvblog'] = $this->mod_blogs->mv_blogs();
		//$data['allblogs'] = $this->mod_blogs->get_all_blogs();
		$data['description'] = 'Find thousand of blogs related with web and technologies';
		$data['keywords'] = 'shakzee blog,shakzee blogs,shakzee';
		$data['title'] = "Blogs | shakzee";
		$this->load->view('home/headfoot/header',$data);
		$this->load->view('home/headfoot/css');
		$this->load->view('home/navbar');
		$this->load->view('blogs/blog',$data);
		$this->load->view('home/headfoot/footer');
		$this->load->view('home/headfoot/js');
	}



	public function readblog($blog_id = null,$slug = null){
		if (empty($blog_id))
		{
			c_flash('alert-error','Something  went wrong please try again.','notfound');
		}
		else
		{
			$data['blog'] = $this->mod_blogs->check_blog($blog_id);
			$data['b_comments'] = $this->mod_blogs->get_blog_comments($data['blog'][0]['b_id']);
			if (count($data['blog']) === 1)
			{

					if ($slug === '' || empty($slug))
				    {
				    	$slug = url_title($data['blog'][0]['blog_title'],'dash', true);
 				       redirect('blogs/readblog/'. $blog_id . '/' . $slug);   
				    }   
				    else
				    {
				    		$discription = 'Author: ' . $data['blog'][0]['fname'] . ' '. $data['blog'][0]['lname'] . ' ,' . word_limiter(strip_tags(base64_decode($data['blog'][0]['blog'])),100,'...');
							add_blog_view($blog_id,get_user_ip());//adding user ip and course +1
							$data['blog_tags'] = $this->mod_blogs->get_blog_tags($data['blog'][0]['b_id']);
							$data['description'] =  $discription;
							$data['keywords'] = $data['blog'][0]['blog_title']; 
							$data['author'] = $data['blog'][0]['fname'] . ' '. $data['blog'][0]['lname'];
							$data['title'] = 'Blogs | ' . $data['blog'][0]['blog_title'] . ' | Shakzee';

							$data['og_site_name'] = "shakzee";
							$data['og_type'] = "article";
							$data['og_title'] = $data['blog'][0]['blog_title'];
							$data['og_url'] = current_url();
							//$data['og_image'] = base_url('assets/images/share.png'); 
							$data['og_description'] = $discription;
							$data['og_image_c'] = base_url('assets/images/blogs/'.$data['blog'][0]['blog_cover']); 
							$data['og_image_type'] = "image/jpeg";

							$this->load->view('home/headfoot/header',$data);
							$this->load->view('home/headfoot/css');
							$this->load->view('home/headfoot/syntaxcss');
							$this->load->view('home/navbar');
							$this->load->view('blogs/blog_post',$data);
							$this->load->view('home/headfoot/footer');
							$this->load->view('home/headfoot/syntaxjs');
							$this->load->view('home/headfoot/js');

				    }   				

			}
			else
			{
				c_flash('alert-error','This Blog is not exist','notfound');
			}
			
		}
		
	}


	public function tagged()
	{
		//echo $arg = $_REQUEST['auth'];
		$arg = $this->input->get('t',true);//$_REQUEST['qtag'];
		//die();`

		if (!empty($arg) || $this->input->get('t',true))
		{
			$config = array();
				$config['full_tag_open'] = '<ul class="pagination gmpg">';
				$config['full_tag_close'] = '</ul>';
				$config['first_link'] = FALSE;
				$config['last_link'] = FALSE;
				$config['first_tag_open'] = '<li>';
				$config['first_tag_close'] = '</li>';
				$config['last_tag_open'] = '<li>';
				$config['last_tag_close'] = '</li>';

				$config['next_link'] = 'Next';
				$config['next_tag_open'] = '<li>';
		        $config['next_tag_close'] = '</li>';
										
				$config['prev_link'] = 'Prev';
				$config['prev_tag_open'] = '<li class="prev">';
		        $config['prev_tag_close'] = '</li>';
				$config['cur_tag_open'] = '<li class="active"><a href="#">';
		        $config['cur_tag_close'] = '</a></li>';
		        $config['num_tag_open'] = '<li>';
		        $config['num_tag_close'] = '</li>';  

			$config["base_url"] = base_url() ."blogs/tagged";
							 
			$sort_tags = $this->mod_blogs->get_blogs_bytag($arg);
			//$sort_tags->num_rows();
			$config["total_rows"] = $sort_tags->num_rows();
			$config["per_page"] = 1;//100;
		    $config["uri_segment"] = 3;
			$config['suffix'] = '?' . http_build_query($_GET, '', "&");
			$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
						 		//$data['get_allcategory']= $this->mod_blog->get_allcategory();
			$this->load->library('pagination');
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
			$data["sort_blog"] = $this->mod_blogs->
				fetch_blogs_bytag($config["per_page"], $page,$arg);
				$data["links"] = $this->pagination->create_links();
			$data['mvblog'] = $this->mod_blogs->mv_blogs();
			$data['title'] = 'Shakzee';	


			$this->load->view('home/headfoot/header',$data);
			$this->load->view('home/headfoot/css');
			$this->load->view('home/navbar');
			$this->load->view('blogs/tagged',$data);
			$this->load->view('home/headfoot/footer');
			$this->load->view('home/headfoot/js');
				
				//var_dump($data["sort_blog"]);
				//die();
		}
		else
		{
			c_flash('alert-error','blog not founds.','notfound');
		}

	}//function ends here

	public function add_guest_user()
	{
		$data['gu_name'] = $this->input->post('name',TRUE);
		$data['gu_email'] = $this->input->post('email',TRUE);
		$data['bc_comment'] = $this->input->post('comment',TRUE);
		$data['blog_id'] = $this->input->post('b998',TRUE);
		$data['bc_guest'] = 1;
		$data['bc_date'] = date("Y-m-d h:i:sa");

		/*var_dump($data);
		die();*/
		if (
				empty($data['gu_name']) || empty($data['gu_email']) || empty($data['bc_comment'] )|| empty( $data['blog_id'])
			)
		{
			if (!empty($data['blog_id']))
			{
				$data['blog_id'] = $this->encrypt->decode($data['blog_id']);
				c_flash('alert-danger','Please check required fields and try again.','blogs/readblog/'.$data['blog_id']);
			}
			else
			{	
				c_flash('alert-danger','Please check required fields and try again.','blogs');
			}
			
			
		}
		else
		{

			$data['blog_id'] = $this->encrypt->decode($data['blog_id']);
			$blog_gst_commnt = $this->mod_blogs->add_blog_comment($data);	
			if (is_integer($blog_gst_commnt))
			{
				c_flash('alert-success','Your comment has been successfully inserted','blogs/readblog/'.$data['blog_id']);
			}
			else
			{
				c_flash('alert-danger','Your comment has not been inserted','blogs/readblog/'.$data['blog_id']);
			}
			
		}
		
	}


	public function addcomment()
	{
		if ($this->input->is_ajax_request())
		{
			$data['bc_comment'] = strip_tags($this->input->post('cmnt',TRUE));
			$data['blog_id'] = $this->input->post('y67xp',TRUE);
			$blog_i_encrypt = $data['blog_id'];
			$uer_id = user_id();
			// $data['message'] = var_dump($uer_id);
			//  echo json_encode($data);
			//  die();
			if (!empty($data['bc_comment']) && !empty($data['blog_id']))
			{
				$data['blog_id'] = $this->encrypt->decode($data['blog_id']);
				$data['user_id'] = $uer_id;
				$data['bc_date'] = date("Y-m-d h:i:sa");
				//$dtext = $this->encrypt->decode($dtext);
				$blog_idx = $this->mod_blogs->add_blog_comment($data);
				 if (is_int($blog_idx))
				 {
				 	$c_b_comment = $this->mod_blogs->get_current_comment($blog_idx);
				 	if (count($c_b_comment) === 1)
				 	{

				 		$c_b_comment['return'] = TRUE;
				 		$c_b_comment['user_img'] =  user_img($uer_id);
				 		$c_b_comment['blog_i_encrypt'] = $blog_i_encrypt;
				 		$c_b_comment['timeago'] = timeago(date("Y-m-d h:i:sa"));
				 		$c_b_comment['commnt_i_encrypt'] = $this->encrypt->encode($c_b_comment[0]['bc_id']);
				 		//$c_b_comment['count'] = count($c_b_comment);
					 	echo json_encode($c_b_comment);
				 	}
				 	else
				 	{
				 		$data['return'] = FALSE;
					 	$data['message'] = 'Your comment has been successfully insert but we can\'t show its right now please refresh your browser.';
					 	echo json_encode($data);
				 	}
				 }
				 else
				 {

				 	$data['return'] = FALSE;
				 	$data['message'] = 'We can\'t insert your comment right now please try again.';
				 	echo json_encode($data);
				 }
				 
			}	
			else
			{
				$data['message'] = 'Please check required fields and try again.';
				echo json_encode($data);
			}
		}
		else
		{
			c_flash('alert-danger','Please write a text to submit your comment.','notfound');
		}

	}
	/*public function addcomment($blog_id,$comment)
	{
			$data['bc_comment'] = $comment; //strip_tags($this->input->post('cmnt',TRUE));
			$data['blog_id'] =$blog_id; //$this->input->post('y67xp',TRUE);
			$blog_i_encrypt = $data['blog_id'];
			$uer_id = user_id();
			// $data['message'] = var_dump($uer_id);
			//  echo json_encode($data);
			//  die();
			if (!empty($data['bc_comment']) && !empty($data['blog_id']))
			{
				//$data['blog_id'] = //$this->encrypt->decode($data['blog_id']);
				$data['user_id'] = $uer_id;
				$data['bc_date'] = date("Y-m-d h:i:sa");
				//$dtext = $this->encrypt->decode($dtext);
				$blog_idx = $this->mod_blogs->add_blog_comment($data);
				 if (is_int($blog_idx))
				 {
				 	$c_b_comment = $this->mod_blogs->get_current_comment($blog_idx);
				 	if (count($c_b_comment) === 1)
				 	{

				 		$c_b_comment['return'] = TRUE;
				 		$c_b_comment['user_img'] =  user_img($uer_id);
				 		$c_b_comment['blog_i_encrypt'] = $blog_i_encrypt;
				 		$c_b_comment['timeago'] = timeago(date("Y-m-d h:i:sa"));
				 		$c_b_comment['commnt_i_encrypt'] = $this->encrypt->encode($c_b_comment[0]['bc_id']);
				 		//$c_b_comment['count'] = count($c_b_comment);
					 	echo json_encode($c_b_comment);
				 	}
				 	else
				 	{
				 		$data['return'] = FALSE;
					 	$data['message'] = 'Your comment has been successfully insert but we can\'t show its right now please refresh your browser.';
					 	echo json_encode($data);
				 	}
				 }
				 else
				 {

				 	$data['return'] = FALSE;
				 	$data['message'] = 'We can\'t insert your comment right now please try again.';
				 	echo json_encode($data);
				 }
				 
			}	
			else
			{
				$data['message'] = 'Please check required fields and try again.';
				echo json_encode($data);
			}

	}*/

	public function editcomment()
	{
		if ($this->input->is_ajax_request())
		{
			$data['bc_comment'] = strip_tags($this->input->post('edcom',TRUE));
			$data['bc_id'] = $this->input->post('text_r98',TRUE);//text_r98 its reply id
	
			//  $data['message'] = var_dump($data);
			//  echo json_encode($data);
			// die();
			if (!empty($data['bc_comment']) && !empty($data['bc_id']))
			{
				$data['bc_id'] = $this->encrypt->decode($data['bc_id']);
				$data['user_id'] = user_id();
				//$dtext = $this->encrypt->decode($dtext);
				$up_comment = $this->mod_blogs->update_blog_comment($data);
				 if ($up_comment)
				 {
				 	$b_comment = $this->mod_blogs->get_current_comment($data['bc_id']);
				 	if (count($b_comment) == 1)
				 	{
				 		$b_comment['return'] = TRUE;
				 		$b_comment['message'] = 'Your comment has been successfully updated.';
				 		$b_comment['comment'] = $data['bc_comment'];
					 	echo json_encode($b_comment);
				 	}
				 	else
				 	{
				 		$data['return'] = FALSE;
					 	$data['message'] = 'Your comment has not been successfully updated but we can\'t show its right now please refresh your browser.';
					 	echo json_encode($data);
				 	}
				 }
				 else
				 {

				 	$data['return'] = FALSE;
				 	$data['message'] = 'We can\'t update your comment right now please try again.';
				 	echo json_encode($data);
				 }
				 
			}	
			else
			{
				$data['message'] = 'Please check required fields and try again.';
				echo json_encode($data);
			}
		}
		else
		{
			c_flash('alert-danger','Please write a text to submit your comment.','notfound');
		}

	}//function ends here


	public function deletecomment()
	{
		if ($this->input->is_ajax_request())
		{
			$data['bc_id'] = $this->input->post('text_r98',TRUE);
			// $data['message'] = var_dump($data['blog_id']);
			// echo json_encode($data);
			// die();
			if (!empty($data['bc_id']))
			{
				$data['bc_id'] = $this->encrypt->decode($data['bc_id']);
				$data['user_id'] = user_id();
				$deletereply = $this->mod_blogs->deletecomment($data);
				 if ($deletereply)
				 {
				 	
				 		$data['return'] = TRUE;
					 	$data['message'] = 'Your comment has been successfully deleted .';
					 	echo json_encode($data);
				 }
				 else
				 {

				 	$data['return'] = FALSE;
				 	$data['message'] = 'We can\'t insert your comment right now please try again.';
				 	echo json_encode($data);
				 }
				 
			}	
			else
			{
				$data['message'] = 'Please check required fields and try again.';
				echo json_encode($data);
			}
		}
		else
		{
			c_flash('alert-danger','Please write a text to submit your comment.','notfound');
		}

	}

	public function addreply()
	{
		if ($this->input->is_ajax_request())
		{
			$data['pcp_reply'] = strip_tags($this->input->post('reply',TRUE));
			$data['comment_id'] = $this->input->post('text_r98',TRUE);
			$comment_d_encr = $data['comment_id'];
			$userid = user_id();
			// $data['message'] = var_dump($data['blog_id']);
			// echo json_encode($data);
			// die();
			if (!empty($data['pcp_reply']) && !empty($data['comment_id']))
			{
				$data['comment_id'] = $this->encrypt->decode($data['comment_id']);
				$data['user_id'] = $userid;
				$data['bcp_date'] = date("Y-m-d h:i:sa");
				//$dtext = $this->encrypt->decode($dtext);
				$blog_id = $this->mod_blogs->add_blog_reply($data);
				 if (is_int($blog_id))
				 {
				 	//$c_b_reply = array();
				 	$c_b_reply = $this->mod_blogs->get_current_reply($blog_id);
				 	if (count($c_b_reply) === 1)
				 	{
				 		$c_b_reply['comment_d_encr'] = $comment_d_encr;
						$c_b_reply['dateago'] = timeago(date("Y-m-d h:i:sa"));
						$c_b_reply['user_pic'] = user_img($userid);  
				 		$c_b_reply['return'] = TRUE;
					 	echo json_encode($c_b_reply);
				 	}
				 	else
				 	{
				 		$data['return'] = FALSE;
					 	$data['message'] = 'Your comment has been successfully insert but we can\'t show its right now please refresh your browser.';
					 	echo json_encode($data);
				 	}
				 }
				 else
				 {

				 	$data['return'] = FALSE;
				 	$data['message'] = 'We can\'t insert your comment right now please try again.';
				 	echo json_encode($data);
				 }
				 
			}	
			else
			{
				$data['message'] = 'Please check required fields and try again.';
				echo json_encode($data);
			}
		}
		else
		{
			c_flash('alert-danger','Please write a text to submit your comment.','notfound');
		}

	}

	public function editreply()
	{
		if ($this->input->is_ajax_request())
		{
			$data['pcp_reply'] = strip_tags($this->input->post('erep',TRUE));
			$data['bcp_id'] = $this->input->post('text_r98',TRUE);//text_r98 its reply id
	
			//  $data['message'] = var_dump($data);
			//  echo json_encode($data);
			// die();
			if (!empty($data['pcp_reply']) && !empty($data['bcp_id']))
			{
				$data['bcp_id'] = $this->encrypt->decode($data['bcp_id']);
				$data['user_id'] = user_id();
				//$dtext = $this->encrypt->decode($dtext);
				$blog_id = $this->mod_blogs->update_blog_reply($data);
				 if ($blog_id)
				 {
				 	$c_b_reply = $this->mod_blogs->get_current_reply($data['bcp_id']);
				 	if (count($c_b_reply) === 1)
				 	{
				 		$c_b_reply['return'] = TRUE;
				 		$c_b_reply['message'] = 'Your comment has been successfully updated.';
					 	echo json_encode($c_b_reply);
				 	}
				 	else
				 	{
				 		$data['return'] = FALSE;
					 	$data['message'] = 'Your comment has not been successfully updated but we can\'t show its right now please refresh your browser.';
					 	echo json_encode($data);
				 	}
				 }
				 else
				 {

				 	$data['return'] = FALSE;
				 	$data['message'] = 'We can\'t update your comment right now please try again.';
				 	echo json_encode($data);
				 }
				 
			}	
			else
			{
				$data['message'] = 'Please check required fields and try again.';
				echo json_encode($data);
			}
		}
		else
		{
			c_flash('alert-danger','Please write a text to submit your comment.','notfound');
		}

	}//function ends here


	public function deletereply()
	{
		if ($this->input->is_ajax_request())
		{
			$data['bcp_id'] = $this->input->post('text_r98',TRUE);
			// $data['message'] = var_dump($data['blog_id']);
			// echo json_encode($data);
			// die();
			if (!empty($data['bcp_id']))
			{
				$data['bcp_id'] = $this->encrypt->decode($data['bcp_id']);
				$data['user_id'] = user_id();
				$deletereply = $this->mod_blogs->deletereply($data);
				 if ($deletereply)
				 {
				 	
				 		$data['return'] = TRUE;
					 	$data['message'] = 'Your comment has been successfully deleted .';
					 	echo json_encode($data);
				 }
				 else
				 {

				 	$data['return'] = FALSE;
				 	$data['message'] = 'We can\'t insert your comment right now please try again.';
				 	echo json_encode($data);
				 }
				 
			}	
			else
			{
				$data['message'] = 'Please check required fields and try again.';
				echo json_encode($data);
			}
		}
		else
		{
			c_flash('alert-danger','Please write a text to submit your comment.','notfound');
		}

	}	


	public function blog_post()
	{

		$hdata['title'] = "Shakzee";
		$this->load->view('home/headfoot/header',$hdata);
		$this->load->view('home/headfoot/css');
		$this->load->view('home/navbar');
		$this->load->view('blogs/blog_post');
		$this->load->view('home/headfoot/footer');
		$this->load->view('home/headfoot/js');

	}

}//class ends here
