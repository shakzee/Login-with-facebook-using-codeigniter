<?php
class Allcourses extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}
	public function index()
	{
		$config = array();
		$config['first_link'] = FALSE;
		$config['first_tag_open'] = '<div class="first">';
		$config['first_tag_close'] = '</div>';
		$config['last_link'] = FALSE;
		$config['last_tag_open'] = '<div class="last">';
		$config['last_tag_close'] = '</div>';
		$config['next_link'] = ' Next ';
		$config['next_tag_open'] = '<span class="next">';
		$config['next_tag_close'] = '</span>';
		$config['prev_link'] = ' previous ';
		$config['next_tag_open'] = '<span class="prev">';
		$config['next_tag_close'] = '</span>'; 
	    $config["base_url"] = base_url().'allcourses';
		
		$tot = $this->mod_allcourses->all_courses();
	 	$config["total_rows"] = $tot->num_rows();
		$config["per_page"] = 5;
	    $config["uri_segment"] = 2;
		$this->pagination->initialize($config);
		$page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
		$data["allcoures"] = $this->mod_allcourses->
		fetch_al_lcourses($config["per_page"], $page);
		$data["links"] = $this->pagination->create_links();

		$hdata['title'] = "Shakzee";
		$this->load->view('home/headfoot/header',$hdata);
		$this->load->view('home/headfoot/css');
		$this->load->view('home/navbar');
		$this->load->view('courses/allcourses',$data);
		$this->load->view('home/headfoot/footer');
		$this->load->view('home/headfoot/js');
	}

	public function coursedetail()
	{
		$hdata['title'] = "Shakzee";
		$this->load->view('home/headfoot/header',$hdata);
		$this->load->view('home/headfoot/css');
		$this->load->view('home/navbar');
		$this->load->view('courses/viewcourses');
		$this->load->view('home/headfoot/footer');
		$this->load->view('home/headfoot/js');
	}


}//class ends here