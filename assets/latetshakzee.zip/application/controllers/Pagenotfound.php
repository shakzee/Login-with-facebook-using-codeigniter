<?php
class Pagenotfound  extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();

	}

	function index()
	{
		$hdata['title'] = "Page Not Found | 404 error | Shakzee";
		$this->load->view('home/headfoot/header',$hdata);
		$this->load->view('home/headfoot/css');
		$this->load->view('home/navbar');
		$this->load->view('404/notfound');
		$this->load->view('home/headfoot/footer');
		$this->load->view('home/headfoot/js');

	}


}//calass ends here

