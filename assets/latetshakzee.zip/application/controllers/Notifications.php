<?php
class Notifications extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}

	function index(){
		if (is_logedin())
		{
				$user_id = user_id();
				$config = array();
				$config['first_link'] = FALSE;
				$config['first_tag_open'] = '<div class="first">';
				$config['first_tag_close'] = '</div>';
				$config['last_link'] = FALSE;
				$config['last_tag_open'] = '<div class="last">';
				$config['last_tag_close'] = '</div>';
				$config['next_link'] = ' Next ';
				$config['next_tag_open'] = '<span class="next">';
				$config['next_tag_close'] = '</span>';
				$config['prev_link'] = ' previous ';
				$config['prev_tag_open'] = '<span class="prev">';
				$config['next_tag_close'] = '</span>'; 
			    $config["base_url"] = base_url().'notifications';
				
				$tot = $this->mod_user->all_notifications($user_id);
			 	$config["total_rows"] = $tot->num_rows();
				$config["per_page"] = 50;
			    $config["uri_segment"] = 2;
				$this->pagination->initialize($config);
				$page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
				$data["notifications"] = $this->mod_user->
				fetch_allnotifications($config["per_page"], $page,$user_id);
				$data["links"] = $this->pagination->create_links();
				$data['title'] = "Courses | shakzee";

				$data['description'] = 'Watch hundreds of free educational video tutorials in urdu langauge on computer programming, web development, web design, frameworks and more';
				$data['keywords'] = 'free, educational, videos, tutorials,shaxee,tutorial in hindi, shakzee, programming, shehzad ahmed, learn, css, php,codeigniter tutorial,bootstrap2,twitter bootstrap,bootstrap tutorial,bootstrap in urdu,urdu,codeigniter in urdu, html5, html, tutorial, mysql,jquery in urdu, beginner, introduction, ajax, jquery tutorial, source code,jquery'; 
				$data['author'] = 'Shehzad Ahmed';

				$this->load->view('home/headfoot/header',$data);
				//echo meta($data['meta']);
				$this->load->view('home/headfoot/css');
				$this->load->view('home/navbar');
				$this->load->view('user/content/notifications',$data);
				$this->load->view('home/headfoot/footer');
				$this->load->view('home/headfoot/js');
		}
		else
		{
			c_flash('alert-warning','Please login first to show your notifications.','login');
		}
		
	}

}//class ends here