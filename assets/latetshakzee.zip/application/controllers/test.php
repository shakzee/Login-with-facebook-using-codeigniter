 <div id="comments">
                          <ol class="molc">
                            <li>
                              <div class="avatar">
                                <a href="#">
                                  <img src="<?php echo user_img($comment->user_id); ?>" alt="" class="img-responsive">
                                </a>
                              </div>
                              <div class="comment_right clearfix">
                                 <?php if(is_logedin()): ?>
                                 <div class="dropdown pull-right crop_9">
                                      <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                        
                                        <span class="caret"></span>
                                      </button>
                                      <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                                        <?php if(user_id() == $comment->user_id): ?>
                                          <li><a href="javascript:void(0)">Edit</a></li>
                                          <li><a href="javascript:void(0)">Delete</a></li>
                                        <?php endif; ?>
                                        <li><a href="javascript:void(0)">Report</a></li>
                                      </ul>
                                  </div>
                                <?php endif; ?>
                                <div class="comment_info">
                                  Posted by 
                                  <a href="#">
                                    <?php echo $comment->fname.nbs(1).$comment->lname?>
                                  </a>
                                  <span>|</span>
                                    <?php echo date('d M Y',strtotime($comment->c_date))?> 
                                  <span>|</span>
                                  <?php if(is_logedin()): ?>
                                    <a href="javascript:void(0)" class="rpcl" data-id="<?php echo $comment->c_id?>">
                                      Reply
                                    </a>
                                    <?php endif; ?>
                                </div>
                                <p>
                                    <?php echo $comment->comment;?>
                                </p>
                              </div>
                               
                               <ul class="vcrp">
                                 <?php 
                                  $reply = v_comment_reply($comment->c_id);
                                  if($reply->num_rows() > 0): 
                                  ?>
                                  <?php foreach($reply->result() as $vc_reply):?>   
                                    <li>
                                      <div class="avatar">
                                        <a href="#">
                                          <img src="<?php echo user_img($vc_reply->user_id); ?>" alt="" class="img-responsive">
                                        </a>
                                      </div>
                                      <div class="comment_right clearfix">
                                          <div class="dropdown pull-right crop_9">
                                            <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                              
                                              <span class="caret"></span>
                                            </button>
                                            <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                                              <li><a href="#">Edit</a></li>
                                              <li><a href="#">Delete</a></li>
                                              <li><a href="#">Report</a></li>
                                            </ul>
                                          </div>
                                        <div class="comment_info">
                                          Posted by 
                                          <a href="#">
                                            <?php echo $vc_reply->fname.nbs(1).$vc_reply->lname;?>
                                          </a>
                                          <span>|</span>
                                             <?php echo date('d M Y',strtotime($vc_reply->vcr_date))?> 
                                          <span>|</span>
                                        </div>
                                        <p>
                                           <?php echo $vc_reply->vc_reply;?>
                                        </p>
                                      </div>
                                    </li>
                                    <li> 
                                      <div class="form-group crptb" id="crp<?php echo $comment->c_id?>">
                                          <input type="text" class="form-control vcri<?php echo $comment->c_id?>">
                                          <button class="button_medium crepl" data-id="<?php echo $comment->c_id?>">reply</button>
                                      </div>
                                    </li>
                                  <?php endforeach; ?>
                                <?php else: ?>
                                  <li> 
                                      <div class="form-group crptb" id="crp<?php echo $comment->c_id?>">
                                          <input type="text" class="form-control vcri<?php echo $comment->c_id?>">
                                          <button class="button_medium crepl" data-id="<?php echo $comment->c_id?>">reply</button>
                                      </div>
                                    </li>
                                 <?php endif; ?>                                
                              </ul>
                            </li>
                          </ol>
                        </div>















comment reply here


 <li class="dcrp dcrp<?php echo $vc_reply->vcr_id;?>">
                                      <div class="avatar">
                                        <a href="#">
                                          <img src="<?php echo user_img($vc_reply->user_id); ?>" alt="" class="img-responsive">
                                        </a>
                                      </div>
                                      <div class="comment_right clearfix">
                                          <?php if(is_logedin())://checking session ?>
                                          <div class="dropdown pull-right crop_9">
                                            <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                              
                                              <span class="caret"></span>
                                            </button>
                                            <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                                              <?php if($vc_reply->user_id == user_id()): ?>
                                                <li>
                                                  <a class="edcntrep" href="javascrip:void(0)" data-text="<?php echo $this->encrypt->encode($vc_reply->vcr_id)?>" data-id="<?php echo $vc_reply->vcr_id;?>">
                                                    Edit
                                                  </a>
                                                </li>
                                                <li>
                                                  <a class="dmcntrep" href="javascrip:void(0)" data-text="<?php echo $this->encrypt->encode($vc_reply->vcr_id)?>" data-id="<?php echo $vc_reply->vcr_id;?>">
                                                    Delete
                                                    </a>
                                                </li>
                                                <?php endif; ?>
                                              <li>
                                                <a hhref="javascrip:void(0)" data-text="<?php echo $this->encrypt->encode($vc_reply->vcr_id)?>" data-id="<?php echo $vc_reply->vcr_id;?>">
                                                  Report
                                                </a>
                                              </li>
                                            </ul>
                                          </div>
                                        <?php endif; //checking session?>
                                        <div class="comment_info">
                                          Posted by 
                                          <a href="#">
                                            <?php echo $vc_reply->fname.nbs(1).$vc_reply->lname;?>
                                          </a>
                                          <span>|</span>
                                             <?php echo date('d M Y',strtotime($vc_reply->vcr_date))?> 
                                          <span>|</span>
                                        </div>
                                        <div class="vcomrep<?php echo $vc_reply->vcr_id;?>">
                                           <?php echo $vc_reply->vc_reply;?>
                                        </div>
                                      </div>
                                    </li>





