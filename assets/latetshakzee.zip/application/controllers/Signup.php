<?php
class Signup extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->clear_cache();
	}

	function index(){
		include_once APPPATH."libraries/facebook-api-php-codexworld/facebook.php";
		//echo 'working...	';
		//die();
		if(is_logedin())
		{
			redirect(site_url());
		}//checking if user already  logedin 
		
		$appId = '425107520978297';
		$appSecret = '394cc5a3c4f11a25361d3f753fe2c95a';
		$redirectUrl = base_url() . 'signup/';
		$fbPermissions = 'email';
		$facebook = new Facebook(array(
		  'appId'  => $appId,
		  'secret' => $appSecret
		
		));
		$fbuser = $facebook->getUser();
		if ($fbuser) {
			$userProfile = $facebook->api('/me?fields=id,first_name,last_name,email,gender,locale,picture');
			//echo $newdata = $userProfile['picture']['data'];
			//var_dump($userProfile['picture']['data']);
			//echo image($userProfile['url']);
			//var_dump($userProfile);
			//echo $userProfile['picture'];
			$fbdata['social_network'] = 'facebook';
			$fbdata['fname'] = $userProfile['first_name'];
			$fbdata['lname'] = $userProfile['last_name'];
			$fbdata['email'] = $userProfile['email'];
			$fbdata['u_gender'] = $userProfile['gender'];
			$fbdata['social_dp'] = $userProfile['picture']['data']['url'];
			$fbdata['teacher'] = 0 ;
			$fbdata['u_status'] = 1 ;
			$fbdata['social'] = 1 ;
			$fbdata['u_created'] = date('Y-m-d H:i:s');
			$fbdata['u_type'] = 1;
			
			$check_email = $this->mod_registration->check_email($fbdata);
			//var_dump($check_email);
			//die();
			if(!empty($check_email) && count($check_email == 1))
			{
				//var_dump($check_email);
				//die();
				
				if($check_email[0]['social'] == 1)
				{
					switch ($check_email[0]['social_network']) {
						case 'facebook':						
							update_fb($fbdata);
							break;
						case 'googleplus':						
							c_flash('alert-warning','Please login with your '. $check_email[0]['social_network'] . ' account.' ,'signup');
							break;
						}//switch ends her
					
				}
				else
				{
					c_flash('alert-warning','Please login with this ' . $check_email[0]['email'] . 'email.' ,'signup');
					
				}
			}
			else
			{
				insert_fb($fbdata);
			}

				/*echo br(2);
				var_dump($userProfile);
				echo br(5);
				var_dump($userProfile['picture']['data']['url']);
				echo img($userProfile['picture']['data']['url']);
				*/
			
			}
		else
		{
			$fbuser = '';
			$data['fburl'] = $facebook->getLoginUrl(array('redirect_uri'=>$redirectUrl,'scope'=>$fbPermissions));
		}/*facebook api ends here*/
		
		if (isset($_GET['code']))//google plus api starts here
		{
			$this->googleplus->getAuthenticate();
			$googldata = $this->googleplus->getUserInfo();
			/*var_dump($googldata);
			die();*/
			$gdata['social_network'] = 'googleplus';
			$gdata['fname'] = $googldata['given_name'];
			$gdata['lname'] = $googldata['family_name'];
			$gdata['email'] = $googldata['email'];
			//$gdata['u_gender'] = $googldata['gender'];
			$gdata['social_dp'] = $googldata['picture'];
			$gdata['teacher'] = 0 ;
			$gdata['u_status'] = 1 ;
			$gdata['social'] = 1 ;
			$gdata['u_created'] = date('Y-m-d H:i:s');
			$gdata['u_type'] = 1;
			$gdata['oauth_uid'] =  $googldata['id'];
			
			$check_email = $this->mod_registration->check_email($gdata);
			//var_dump($check_email);
			if(!empty($check_email) && count($check_email == 1))
			{
				if($check_email[0]['social'] == 1)
				{
					switch ($check_email[0]['social_network']) {
						case 'facebook':
								c_flash('alert-warning','Please login with your '. $check_email[0]['social_network'] . ' account.' ,'signup');
							break;
						case 'googleplus':						
							update_googleplus($gdata);
							break;
						}//switch ends her
					
				}
				else
				{
					//echo 'hereis..';
					//die();
					c_flash('alert-warning','Please login with this ' . $check_email[0]['email'] . ' email.' ,'signup');
					
				}
			}
			else
			{
				insert_googleplus($gdata);
			}

			//var_dump($gdata);
		}
		
		$data['g_login_url'] = $this->googleplus->loginURL();	
		$data['title'] = "Signup | shakzee";
		$this->load->view('home/headfoot/header',$data);
		$this->load->view('home/headfoot/css');
		$this->load->view('home/navbar');
		$this->load->view('registration/signup',$data);
		$this->load->view('home/headfoot/footer');
		$this->load->view('home/headfoot/js');

	}


	public function newaccount()
	{

		$data['fname'] = $this->input->post('fname',TRUE);
		$data['lname'] = $this->input->post('lname',TRUE);
		$data['email'] = $this->input->post('email',TRUE);
		$data['password'] = $this->input->post('password',TRUE);
		$data['u_gender'] = $this->input->post('gender',TRUE);
		$data['u_created'] = date('Y-m-d H:i:s'); 
		
		if (
				empty($data['fname']) || empty($data['lname']) || empty($data['email']) || 
				empty($data['password']) || empty($data['u_gender']) 
			)
		{
			c_flash('alert-warning','Please Check required fields and try again.','signup');
		}
		else
		{
			$check_user = $this->mod_registration->check_user($data);	
			if ($check_user->num_rows() > 0 )
			{
				c_flash('alert-warning',' This email ' . $data['email'] . ' is already exist','signup');
			}
			else
			{
				$data['password'] = do_hash($data['password']);
				$data['confirm_pass'] = random_string('alnum', 20);
				switch ($data['u_gender']) {
					case 'male':
						$data['u_dp'] = 'male.jpg';
						break;
					case 'female':
						$data['u_dp'] = 'female.jpg'; 
						break;
					}
				$new_acount = $this->mod_registration->create_new_account($data);
				if ($new_acount)
				{
					echo 'Send email here';
				}
				else
				{
					echo 'not inserted...';
				}

			}
			
		}
		

	}

	public function confirm($value)
	{
		if (empty($value))
		{
			c_flash('alert-warning','Please check your email and try again.','signup');
		}
		else
		{
			//echo $value;
			//die();
			$check_link = $this->mod_registration->check_link($value);
			if ($check_link->num_rows() === 1)
			{
				$data['u_status'] = 1;  
				$data['confirm_pass'] = $value.'ok'; 
				$confirm = $this->mod_registration->confirm_account($data,$value);
				if ($confirm)
				{
					c_flash('alert-success','You have successfully varified your account please login now.','login');
				}
				else 
				{
					c_flash('alert-success','Oops we can\'t varified your account please try again.' ,'login');
				}
				
			}
			else
			{
				c_flash('alert-warning','Your link is expired or wrong please check you email and try again.','signup');
			}
			
		}
		
	}

	function clear_cache()
    {
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
    }
	
	
}//class ends here
