<?php
class Courses extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->clear_cache();
	}
	public function index()
	{
		//var_dump($this->session->userdata('u_id')).'ok.';
		//echo ;
		//die();
		$config = array();
		$config['first_link'] = FALSE;
		$config['first_tag_open'] = '<div class="first">';
		$config['first_tag_close'] = '</div>';
		$config['last_link'] = FALSE;
		$config['last_tag_open'] = '<div class="last">';
		$config['last_tag_close'] = '</div>';
		$config['next_link'] = ' Next ';
		$config['next_tag_open'] = '<span class="next">';
		$config['next_tag_close'] = '</span>';
		$config['prev_link'] = ' previous ';
		$config['prev_tag_open'] = '<span class="prev">';
		$config['next_tag_close'] = '</span>'; 
	    $config["base_url"] = base_url().'courses';
		
		$tot = $this->mod_courses->all_courses();
	 	$config["total_rows"] = $tot->num_rows();
		$config["per_page"] = 20;
	    $config["uri_segment"] = 2;
		$this->pagination->initialize($config);
		$page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
		$data["allcoures"] = $this->mod_courses->
		fetch_al_lcourses($config["per_page"], $page);
		$data["links"] = $this->pagination->create_links();
		$data['title'] = "Courses | shakzee";

		$data['description'] = 'Watch hundreds of free educational video tutorials in urdu langauge on computer programming, web development, web design, frameworks and more';
		$data['keywords'] = 'free, educational, videos, tutorials,shaxee,tutorial in hindi, shakzee, programming, shehzad ahmed, learn, css, php,codeigniter tutorial,bootstrap2,twitter bootstrap,bootstrap tutorial,bootstrap in urdu,urdu,codeigniter in urdu, html5, html, tutorial, mysql,jquery in urdu, beginner, introduction, ajax, jquery tutorial, source code,jquery'; 
		$data['author'] = 'Shehzad Ahmed';


		$this->load->view('home/headfoot/header',$data);
		//echo meta($data['meta']);
		$this->load->view('home/headfoot/css');
		$this->load->view('home/navbar');
		$this->load->view('courses/allcourses',$data);
		$this->load->view('home/headfoot/footer');
		$this->load->view('home/headfoot/js');
	}

	public function detail($course_id = null,$slug = null)
	{
		if (empty($course_id))
		{
			c_flash('alert-warning','Please select a course to view detail.','courses');
		}
		else
		{
			$data['course'] = $this->mod_courses->check_course($course_id);
			if (count($data['course']) == 1)
			{
				if($slug === '' || empty($slug))
				{
					$slug = url_title($data['course'][0]['course_name'],'dash', true);
					redirect('courses/detail/'. $course_id . '/' . $slug);   
				}//if slug
				else
				{
					add_course_view($course_id,get_user_ip());//adding user ip and course +1
					//die();
					if($data['course'][0]['course_type'] != 'free')
					{
						if (is_logedin())
						{
							if (
									$this->session->userdata('u_type') == 2 ||
									$this->session->userdata('u_type') == 3 ||
									$this->session->userdata('u_id') == $data['course'][0]['user_id']
								)
							{
								
								$data['all_videos'] = $this->mod_courses->all_videos($data['course'][0]['c_id']);
								$data['title'] = $data['course'][0]['course_name'].' | '.$data['course'][0]['course_level'] . ' | shakzee';
								$data['description'] = word_limiter($data['course'][0]['course_desc'],100);
								$data['keywords'] = $data['course'][0]['course_name'] . ' in urdu,'.$data['course'][0]['course_name'] . ' in hindi,'.$data['course'][0]['course_name'] . ' course,' .$data['course'][0]['course_name']. ' ' .$data['course'][0]['course_level']; 
								$data['author'] = $data['course'][0]['fname']. ' ' .$data['course'][0]['lname'] ;

								$data['og_site_name'] = "shakzee";
								$data['og_type'] = "article";
								$data['og_title'] = $data['course'][0]['course_name'].' | '.$data['course'][0]['course_level'] . ' | shakzee';
								$data['og_url'] = current_url();
								//$data['og_image'] = base_url('assets/images/share.png'); 
								$data['og_description'] = word_limiter($data['course'][0]['course_desc'],100);
								$data['og_image_c'] = base_url('assets/images/courses/'.$data['course'][0]['course_cover']); 
								$data['og_image_type'] = "image/jpeg";

								$this->load->view('home/headfoot/header',$data);
								$this->load->view('home/headfoot/css');
								$this->load->view('home/navbar');
								$this->load->view('courses/viewcourses',$data);
								$this->load->view('home/headfoot/footer');
								$this->load->view('home/headfoot/syntaxjs');
								$this->load->view('home/headfoot/js');			

							}
							else
							{
								c_flash('alert-warning','This Course available only for Advance And Pro users, Please upgrade your account to view this course.','courses');
							}
							
						}
						else
						{
							c_flash('alert-warning','Please Login to view this Course.','courses');
						}//else if user logedin

					}
					else
					{
						
						$data['all_videos'] = $this->mod_courses->all_videos($data['course'][0]['c_id']);
						$data['title'] = $data['course'][0]['course_name'].' | '.$data['course'][0]['course_level'] . ' | shakzee';
						$data['description'] = word_limiter($data['course'][0]['course_desc'],100);
						$data['keywords'] = $data['course'][0]['course_name'] . ' in urdu,'.$data['course'][0]['course_name'] . ' in hindi,'. $data['course'][0]['course_name'] . ' course, ' . $data['course'][0]['course_name']. ' ' .$data['course'][0]['course_level']; 
						$data['author'] = $data['course'][0]['fname']. ' ' .$data['course'][0]['lname'] ;
						$data['og_site_name'] = "shakzee";
						$data['og_type'] = "article";
						$data['og_title'] = $data['course'][0]['course_name'].' | '.$data['course'][0]['course_level'] . ' | shakzee';
						$data['og_url'] = current_url();
								//$data['og_image'] = base_url('assets/images/share.png'); 
						$data['og_description'] = word_limiter($data['course'][0]['course_desc'],100);
						$data['og_image_c'] = base_url('assets/images/courses/'.$data['course'][0]['course_cover']); 
						$data['og_image_type'] = "image/jpeg";
						$this->load->view('home/headfoot/header',$data);
						$this->load->view('home/headfoot/css');
						$this->load->view('home/navbar');
						$this->load->view('courses/viewcourses',$data);
						$this->load->view('home/headfoot/footer');
						$this->load->view('home/headfoot/syntaxjs');
						$this->load->view('home/headfoot/js');			

					}
				}//checking slug
			}//if course found
			else
			{
				c_flash('alert-warning','Course not found.','courses');
			}//else if course not found.
			
		}//empty else her
		
	}

	public function video($video_id = null,$slug = null)
	{
		if (empty($video_id))
		{
			c_flash('alert-warning','Please select lecture to view.','courses');
		}
		else
		{
			$data['my_video'] = $this->mod_courses->check_video($video_id);
			if (count($data['my_video']) == 1)
			{
				if ($slug === '' || empty($slug))
				{
				   	$slug = url_title($data['my_video'][0]['video_name'],'dash', true);
 				     redirect('courses/video/'. $video_id . '/' . $slug);   
				}
				else
				{
					add_video_view($video_id,get_user_ip());//adding user ip and video +1
					$data['all_comments'] = $this->mod_courses->get_all_comments($data['my_video'][0]['v_id']);
					if ($data['my_video'][0]['course_type'] != 'free')
					{
						if (is_logedin())
						{
							if (
									$this->session->userdata('u_type') == 2 ||
									$this->session->userdata('u_type') == 3 ||
									$this->session->userdata('u_id') == $data['my_video'][0]['user_id']
								)
							{
								$data['all_videos'] = $this->mod_courses->all_videos($data['my_video'][0]['c_id']);
								$data['title'] = $data['my_video'][0]['video_name'] . ' | '. $data['my_video'][0]['course_name'] . ' | Shakzee';
								$data['description'] = 'Watch hundreds of free educational video tutorials in urdu langauge on computer programming, web development, web design, frameworks and more';
								$data['keywords'] = 'free, educational, videos, tutorials,shaxee,tutorial in hindi, shakzee, programming, shehzad ahmed, learn, css, php,codeigniter tutorial,bootstrap2,twitter bootstrap,bootstrap tutorial,bootstrap in urdu,urdu,codeigniter in urdu, html5, html, tutorial, mysql,jquery in urdu, beginner, introduction, ajax, jquery tutorial, source code,jquery'; 
								$data['author'] = $data['my_video'][0]['fname'];							

								$this->load->view('home/headfoot/header',$data);
								$this->load->view('home/headfoot/css');
								$this->load->view('home/navbar');
								$this->load->view('courses/video',$data);
								$this->load->view('home/headfoot/footer');
								$this->load->view('home/headfoot/syntaxjs');
								$this->load->view('home/headfoot/js');			

							}
							else
							{
								c_flash('alert-warning','This Course available only for Advance And Pro users, Please upgrade your account to view this course.','courses');
							}
						}
						else
						{
							c_flash('alert-warning','Please Login to view this Course.','courses');
						}
					}
					else
					{
						$data['all_videos'] = $this->mod_courses->all_videos($data['my_video'][0]['c_id']);
						$data['title'] = $data['my_video'][0]['video_name'] . ' | '. $data['my_video'][0]['course_name'] . ' | shakzee';
						$data['description'] = 'Watch ' . $data['my_video'][0]['video_name'] . ' and learn many things from it.';
						$data['keywords'] = $data['my_video'][0]['video_name'] . ' in urdu,'. $data['my_video'][0]['video_name'] . ' in hindi,' . $data['my_video'][0]['video_name']; 
						$data['author'] = $data['my_video'][0]['fname']. ' ' . $data['my_video'][0]['lname'] ;					
						
						$this->load->view('home/headfoot/header',$data);
						$this->load->view('home/headfoot/css');
						$this->load->view('home/navbar');
						$this->load->view('courses/video',$data);
						$this->load->view('home/headfoot/footer');
						$this->load->view('home/headfoot/syntaxjs');
						$this->load->view('home/headfoot/js');
					}
				} 
				
				
			}
			else
			{
				c_flash('alert-warning','Course not found.','courses');
			}//else if course not found.
			
		}//empty else her
		
	}

	public function newslater()
	{
		$data['email'] = $this->input->post('enltr',TRUE);
		$data['nl_created'] = date_time();
		if (empty($data['email']))
		{
			echo 'empty ha';
		}
		else
		{
			$check_user = $this->mod_courses->check_al_register($data);
			if (count($check_user) > 0 )
			{
				if ($check_user[0]['nl_status'] == 0)
				{
					$update = $this->mod_courses->update_newslater($data);
					if ($update)
					{
						echo 'Your have successfully subscribed.';

					}
					else
					{
						echo 'Oops something going wrong please try again.';
					}
				}
				else
				{
					echo 'Your are already registered';
				}
			}
			else
			{
				$news_later = $this->mod_courses->news_later($data);
				if ($news_later)
				{
					echo 'Your have successfully subscribed.';
				}
				else
				{
					echo 'Oops something going wrong please try again.';
				}

			}
			
			
		}
		
	}

	public function addcomment(){

		if (is_logedin())
		{
	 		$comment['comment'] = strip_tags($this->input->post('vc_91',TRUE));//comment
			$comment['video_id'] = $this->encrypt->decode($this->input->post('vd_34',TRUE));//video_id
			$current_url = $this->input->post('nlnk',TRUE);
			// echo 'yes login here';
			// die();
			if (
					empty($comment['comment']) || empty($comment['video_id']) || empty($current_url)
				)
			{
				echo 'empty error here';
			}
			else
			{
				$comment['user_id'] = user_id();//user 
				$comment['c_date'] = date_time();		
				$addcom = $this->mod_courses->addcomment($comment);
				if (is_integer($addcom))
				{
					$reciver_id = $this->input->post('rc_9',TRUE);//user_id who post video i.e teacher
					$noti = array();
					$noti['n_message'] = 'Commented on your';
					$noti['n_link'] = $this->encrypt->decode($current_url); 
					$noti['receiver_id'] = $this->encrypt->decode($reciver_id); 
			 		$noti['mod_type'] = 1;
			 		$noti['n_type'] = 'video_comment';
					$noti['video_id'] = $comment['video_id'];

					insert_noti($noti);

					$comment['u_img'] = user_img($comment['user_id']);  
					$comment['c_date'] = date('d M Y',strtotime(date_time()));
					$comment['c_id']= $addcom;
					$comment['enc_id']= $this->encrypt->encode($addcom);
					$comment['fname'] = u_s_data('fname');
					$comment['lname'] = u_s_data('lname');
					
					echo json_encode($comment);
					//$this->mod_courses->get_currnet_comment();
					//echo TRUE;
				}
				else
				{
					echo FALSE;
				}
				
				//redirect('home');

			}
			

		}
		else
		{
			echo 'redirect here';
		}
		
	}

	public function ago()
	{
		echo date_time();
		echo br();
		echo time_ago(date_time());
	}
	public function vcoomment_reply()
	{
		if (is_logedin())
		{
			$comment['vc_reply'] = strip_tags($this->input->post('reply',TRUE));//comment reply
			$video_comment_id = $this->input->post('text_id',TRUE);//comment id
			$reciver_id = $this->input->post('curs',TRUE);//comment reply
			$current_url = $this->input->post('nlnk',TRUE);
			$comment['user_id'] = user_id();//user id
			$comment['vcr_date'] = date_time();	

			if (
					!empty($comment['vc_reply']) || !empty($video_comment_id) || !empty($reciver_id)
				)
			{
				$comment['vido_com_id'] = $this->encrypt->decode($video_comment_id);
				$addcom = $this->mod_courses->add_video_coomment_reply($comment);
				if (is_integer($addcom))
				{

					//$reciver_id = $this->input->post('rc_9',TRUE);//user_id who post video i.e teacher
					$noti = array();
					$noti['n_message'] = 'Replied on your comment';
					$noti['n_link'] = $this->encrypt->decode($current_url); 
					$noti['receiver_id'] = $this->encrypt->decode($reciver_id); 
			 		$noti['mod_type'] = 1;
			 		$noti['n_type'] = 'video_comment_reply';
					$noti['video_id'] = $comment['vido_com_id'];

					insert_noti($noti);

					$comment['vcid'] = $video_comment_id;
					$comment['u_img'] = user_img($comment['user_id']);  
					$comment['c_date'] = date('d M Y',strtotime(date_time()));
					$comment['rep_id']= $addcom;
					$comment['envcr_id'] =  $this->encrypt->encode($addcom);
					$comment['fname'] = u_s_data('fname');
					$comment['lname'] = u_s_data('lname');
					$comment['return'] = 'TRUE';
					//echo TRUE;
					echo json_encode($comment);
				}
				else
				{
					echo $comment['return'] = 'FALSE';
					//echo FALSE;
				}
				
			}
			else
			{
				echo 'empty error  here';
			}

		}
		else
		{
			echo 'redirect here';
		}
		
	}

	public function delcomment()
	{
		if (is_logedin())
		{
			$data['c_id'] = $this->input->post('ctext',TRUE);
			if (!empty($data['c_id']))
			{
				$data['user_id'] = user_id();
				$data['c_id'] = $this->encrypt->decode($data['c_id']); 
				$delcom = $this->mod_courses->delcomment($data);
				//die();
				if ($delcom)
				{
					echo 'Your comment has been deleted successfully.';
				}
				else
				{
					echo 'Something went wrong please try again.';
				}
				
			}
			else
			{

			}
			
		}
		else
		{

		}
		
	}

	public function delrepcomment()
	{
		if (is_logedin())
		{
			$data['vcr_id'] = $this->input->post('ctext',TRUE);
			if (!empty($data['vcr_id']))
			{
				$data['user_id'] = user_id();
				$data['vcr_id'] = $this->encrypt->decode($data['vcr_id']); 
				$delrepcomment = $this->mod_courses->delrepcomment($data);
				//die();
				if ($delrepcomment)
				{
					echo 'Your comment has been deleted successfully.';
				}
				else
				{
					echo 'Something went wrong please try again.';
				}
				
			}
			else
			{
				echo 'empty here';
			}
			
		}
		else
		{
			echo 'login here';
		}
		
	}



	public function updatecomemnt()
	{
		if (is_logedin())
		{
			$data['c_id'] = $this->input->post('ctext',TRUE);
			$data['comment'] = $this->input->post('comment',TRUE);

			if (!empty($data['c_id']) || !empty($data['comment']))
			{
				$data['user_id'] = user_id();
				$data['c_id'] = $this->encrypt->decode($data['c_id']); 
				$updatecomemnt = $this->mod_courses->updatecomemnt($data);
				//die();
				if ($updatecomemnt)
				{
					echo 'Your comment has been successfully updated.';
				}
				else
				{
					echo 'Something went wrong please try again.';
				}
				
			}
			else
			{
				echo 'Please check required fields and try agai.';
			}
			
		}
		else
		{
			echo 'login here';
		}
		
	}

	public function updatecomemntrep()
	{
		if (is_logedin())
		{
			$data['vcr_id'] = $this->input->post('ctext',TRUE);
			$data['vc_reply'] = $this->input->post('comment',TRUE);

			if (!empty($data['vcr_id']) || !empty($data['vc_reply']))
			{
				$data['user_id'] = user_id();
				$data['vcr_id'] = $this->encrypt->decode($data['vcr_id']); 
				$updatecomemntrep = $this->mod_courses->updatecomemntrep($data);
				//die();
				if ($updatecomemntrep)
				{
					echo 'Your comment has been successfully updated.';
				}
				else
				{
					echo 'Something went wrong please try again.';
				}
				
			}
			else
			{
				echo 'Please check required fields and try agai.';
			}
			
		}
		else
		{
			echo 'login here';
		}
		
	}

	public function videolike()
	{
		if (is_logedin())
		{
			//$data['user_id'] = $this->input->post('rc_9',TRUE);
			$data['video_id'] = $this->input->post('vd_34',TRUE);
			//die();
			$data['user_id'] = user_id();
			$data['l_date'] = date_time(); 
			if (
					!empty($data['user_id']) || !empty($data['video_id'])
				)
			{
				$data['video_id'] = $this->encrypt->decode($data['video_id']);
				//$data['video_id'] = $this->encrypt->decode($data['video_id']);
				//die();
				 $check = $this->mod_courses->check_l_d($data);
				if (count($check) == 1)
				{
					if ($check[0]['dlike'] == 1)
					{
						$udata['like'] = 1;
						$udata['dlike'] = 0;
						$up_like = $this->mod_courses->update_video_like($data,$udata);
						if ($up_like)
						{
							echo $likes = get_videos_likes($data);
						}
						else
						{
							echo 'false';
							
						}
					}
					else if($check[0]['like'] == 1)
					{
						$udata['like'] = 0;
						$user_id['l_status'] = 0;
						$up_like = $this->mod_courses->update_video_like($data,$udata);
						if ($up_like)
						{
							echo $likes = get_videos_likes($data);
						}
						else
						{
							echo 'false';
						}

					}
					else
					{

						$udata['like'] = 1;
						$user_id['l_status'] = 1;
						$up_like = $this->mod_courses->update_video_like($data,$udata);
						if ($up_like)
						{
							echo $likes = get_videos_likes($data);

						}
						else
						{
							echo 'false';
							// echo json_encode(array('return' =>0));
						// 	$res = 
						// 	array(
						// 			'return' =>0
						// 		);
						// 	echo json_encode($res);
						}
						
 					}
					
				}
				else
				{
					$data['like'] = 1;
					$addlike = $this->mod_courses->insert_video_like($data);
					if ($addlike)
					{

						echo  $likes = get_videos_likes($data);
					}
					else
					{
						echo 'false';
					}
					
				}
				
			}
			else
			{
				echo 'empty here';
			}
			
		}
		else
		{

		}
		
	}

	public function videodlike()
	{
		if (is_logedin())
		{
			//$data['user_id'] = $this->input->post('rc_9',TRUE);
			$data['video_id'] = $this->input->post('vd_34',TRUE);
			//die();
			$data['user_id'] = user_id();
			$data['l_date'] = date_time(); 
			if (
					!empty($data['user_id']) || !empty($data['video_id'])
				)
			{
				$data['video_id'] = $this->encrypt->decode($data['video_id']);
				//$data['video_id'] = $this->encrypt->decode($data['video_id']);
				//die();
				 $check = $this->mod_courses->check_l_d($data);
				if (count($check) == 1)
				{
					if ($check[0]['like'] == 1)
					{
						$udata['like'] = 0;
						$udata['dlike'] = 1;
						$up_like = $this->mod_courses->update_video_like($data,$udata);
						if ($up_like)
						{
							echo $likes = get_videos_dlikes($data);
						}
						else
						{
							echo 'false';
							
						}
					}
					else if($check[0]['dlike'] == 1)
					{
						echo 'dlike here';
						die();
						$udata['dlike'] = 0;
						$user_id['l_status'] = 0;
						$up_like = $this->mod_courses->update_video_like($data,$udata);
						if ($up_like)
						{
							echo $likes = get_videos_dlikes($data);
						}
						else
						{
							echo 'false';
						}

					}
					else
					{

						$udata['dlike'] = 1;
						$udata['like'] = 0;
						$user_id['l_status'] = 1;
						$up_like = $this->mod_courses->update_video_like($data,$udata);
						if ($up_like)
						{
							echo $likes = get_videos_dlikes($data);

						}
						else
						{
							echo 'false';
							// echo json_encode(array('return' =>0));
						// 	$res = 
						// 	array(
						// 			'return' =>0
						// 		);
						// 	echo json_encode($res);
						}
						
 					}
					
				}
				else
				{
					$data['dlike'] = 1;
					$addlike = $this->mod_courses->insert_video_like($data);
					if ($addlike)
					{

						echo $likes = get_videos_dlikes($data);
					}
					else
					{
						echo 'false';
					}
					
				}
				
			}
			else
			{
				echo 'empty here';
			}
			
		}
		else
		{

		}
		
	}
// $data['cw_status'] = 1;
// 					$c_unwish = $this->mod_courses->couse_unwish($data);
	public function coursewishlist()
	{
		if ($this->input->is_ajax_request())
		{
			if (is_logedin())
			{
				$data['course_id'] = $this->input->post('text',TRUE);
				$data['course_id'] = $text = $this->encrypt->decode($data['course_id']);
				$data['user_id'] = user_id();
				$data['cw_created'] = 1; 
				$data['cw_status'] = 1;
				$data['cw_created'] = date_time();
				 //var_dump($data); 
				 //die();
				$cclist = $this->mod_courses->check_course_wisht($data);
				if (count($cclist) == 1)
				{
					 // echo 'ok here';
					 // var_dump($cclist); 
					 // die();
					if ($cclist[0]['cw_status'] == 1)
					{
						$data['cw_status'] = 0;
						$c_unwish = $this->mod_courses->couse_unwish($data);
						if ($c_unwish)
						{
							$data['return'] = 'true';
							$data['status'] = 'update';
							echo json_encode($data);
						}
						else
						{
							$data['return'] = 'false';
							$data['status'] = 'update';
							echo json_encode($data);
						}
						
					}
					else if($cclist[0]['cw_status'] == 0)
					{
						$data['cw_status'] = 1;
						//$c_unwish = $this->mod_courses->couse_unwish($data);
						$c_unwish = $this->mod_courses->couse_unwish($data);
						if ($c_unwish)
						{
							$data['return'] = 'true';
							$data['status'] = 'update';
							echo json_encode($data);

						}
						else
						{
							$data['return'] = 'false';
							$data['status'] = 'update';
							echo json_encode($data);

						}

					}
					
				}
				else
				{
					// echo 'else here';
					$c_unwish = $this->mod_courses->add_couse_wish($data);
					// var_dump($c_unwish);
					if ($c_unwish)
					{
						$data['return'] = 'true';
						$data['status'] = 'insert';
						echo json_encode($data);

					}
					else
					{
						$data['return'] = 'false';
						$data['status'] = 'insert';
						json_encode($data);

					}

				}
				
			}//login here
			else
			{
				$data['return'] = 'false';
				json_encode($data);
			}
			
		}//ajax here
		else
		{
				c_flash('alert-warning','Something went wrong please try again.','pagenotfound');
		}
		
	}


	public function procoursewishlist()
	{
		if ($this->input->is_ajax_request())
		{
			if (is_logedin())
			{
				$data['pro_course_id'] = $this->input->post('text',TRUE);
				$data['pro_course_id'] = $text = $this->encrypt->decode($data['pro_course_id']);
				$data['user_id'] = user_id();
				$data['pcw_status'] = 1;
				$data['pcw_date'] = date_time();
				// var_dump($data); 
				// die();
				$cclist = $this->mod_courses->pro_check_course_wisht($data);
				if (count($cclist) === 1)
				{
					if ($cclist[0]['pcw_status'] == 1)
					{
						$data['pcw_status'] = 0;
						$c_unwish = $this->mod_courses->pro_couse_unwish($data);
						if ($c_unwish)
						{
							$data['return'] = 'true';
							$data['status'] = 'update';
							echo json_encode($data);
						}
						else
						{
							$data['return'] = 'false';
							$data['status'] = 'update';
							echo json_encode($data);
						}
						
					}
					
					else if($cclist[0]['pcw_status'] == 0)
					{
						$data['pcw_status'] = 1;
						//$c_unwish = $this->mod_courses->couse_unwish($data);
						$c_unwish = $this->mod_courses->pro_couse_unwish($data);
						if ($c_unwish)
						{
							$data['return'] = 'true';
							$data['status'] = 'update';
							echo json_encode($data);

						}
						else
						{
							$data['return'] = 'false';
							$data['status'] = 'update';
							echo json_encode($data);

						}

					}
					
				}
				else
				{
					$c_unwish = $this->mod_courses->pro_add_couse_wish($data);
					if ($c_unwish)
					{
						$data['return'] = 'true';
						$data['status'] = 'insert';
						echo json_encode($data);

					}
					else
					{
						$data['return'] = 'false';
						$data['status'] = 'insert';
						json_encode($data);

					}

				}
				
			}
			else
			{
				$data['return'] = 'false';
				json_encode($data);
			}
			
		}
		else
		{
				c_flash('alert-warning','Something went wrong please try again.','pagenotfound');
		}
		
	}
	function clear_cache()
    {
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
    }

	
}//class ends here