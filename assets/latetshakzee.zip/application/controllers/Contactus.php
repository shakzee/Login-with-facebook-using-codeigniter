<?php
class Contactus extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}
	public function index()
	{

		$hdata['title'] = "Contact Us | shakzee";
		//$this->mod->contactus->get_courses();
		$this->load->view('home/headfoot/header',$hdata);
		$this->load->view('home/headfoot/css');
		$this->load->view('home/navbar');
		$this->load->view('contact/contact');
		$this->load->view('home/headfoot/footer');
		$this->load->view('home/headfoot/js');

	}

	public function submitquery()
	{
		if (is_logedin())
		{
			$data['m_title'] = $this->input->post('title',TRUE);
			$data['message'] = $this->input->post('message',TRUE);
			$data['user_id'] = user_id();
			$data['m_created'] = date('Y-m-d H:i:s');
			if (empty($data['m_title']) || empty($data['message']))
			{
				c_flash('alert-warning','please check required fields and try again','contactus');
			}
			else
			{
				$submit_query = $this->mod_contactus->submitquery($data);
				if ($submit_query)
				{
					c_flash('alert-success','Your message has been successfully received, we will contact you as soon as possible.','contactus');
				}
				else
				{
					c_flash('alert-warning','please check required fields and try again','contactus');
				}

			}
			
			
		}
		else
		{
			$data['m_title'] = $this->input->post('title',TRUE);
			$data['message'] = $this->input->post('message',TRUE);
			$data['fname'] = $this->input->post('fname',TRUE);
			$data['lname'] = $this->input->post('lname',TRUE);
			$data['email'] = $this->input->post('email',TRUE);
			$data['phone'] = $this->input->post('phone',TRUE);
			$data['m_created'] = date('Y-m-d H:i:s');
			if (
				empty($data['m_title']) || empty($data['message']) || 
				empty($data['fname']) || empty($data['lname']) || 
				empty($data['email']) 
				)
			{
				c_flash('alert-warning','please check required fields and try again','contactus');
			}
			else
			{
				$submit_query = $this->mod_contactus->submitquery($data);
				if ($submit_query)
				{
					c_flash('alert-success','Your message has been successfully received, we will contact you as soon as possible.','contactus');
				}
				else
				{
					c_flash('alert-warning','please check required fields and try again','contactus');
				}
			}
			
		}
		
	}

}//calss ends here