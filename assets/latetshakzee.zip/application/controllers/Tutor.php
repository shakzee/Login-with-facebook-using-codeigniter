<?php
class Tutor extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}

	function index()
	{

		//echo 'welcome in tutor..';
		if (is_teacher())
		{
			$data['title'] =  'Teacher - Login | shakzee';
			$this->load->view('tutor/header/header',$data);
			$this->load->view('tutor/css/css');
			$this->load->view('tutor/navbar/navbartop');
			$this->load->view('tutor/navbar/navbar_left');
			$this->load->view('tutor/content/home');
			$this->load->view('tutor/footer/footer');
			$this->load->view('tutor/js/admin_extrajs');			
			$this->load->view('tutor/js/js');	
		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','admin/login');
		}
		
	}

	public function newcourse()
	{
		if (is_teacher())
		{
			$data['title'] =  'Add Courses | shakzee';
			$this->load->view('tutor/header/header',$data);
			$this->load->view('tutor/css/css');
			$this->load->view('tutor/navbar/navbartop');
			$this->load->view('tutor/navbar/navbar_left');
			$this->load->view('tutor/content/addcourse');
			$this->load->view('tutor/footer/footer');
			//$this->load->view('tutor/js/admin_extrajs');			
			$this->load->view('tutor/js/js');	
		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','admin/login');
		}

	}

	public function addcourse()
	{
		$data['course_name'] = $this->input->post('coursename',TRUE);
		$data['course_desc'] = $this->input->post('coursedesc',TRUE);
		$data['course_level'] = $this->input->post('courselevel',TRUE);
		$data['course_type'] = $this->input->post('coursetype',TRUE);
		$data['c_views'] = $this->input->post('courseview',TRUE);
		$data['user_id'] = $this->session->userdata('u_id'); 
		$data['course_date'] = date_time();
		if (
				empty($data['course_name']) || empty($data['course_desc']) ||
				empty($data['course_level']) || empty($data['course_type'])
			)
		{
			c_flash('alert-warning','Please check required fields and try again.','tutor/newcourse');
		}
		else 
		{
			$check_user = $this->mod_tutor->chck_course($data);
			if ($check_user->num_rows() > 0)
			{
				c_flash('alert-warning','This course ' . $data['course_name'] . ' already exist.','tutor/newcourse');
			}
			else
			{

					$image_path = realpath(APPPATH . '../assets/images/courses');
					$config['upload_path'] = $image_path;
					$config['allowed_types'] = 'gif|jpg|png';
					$config['max_size']	= '20000';
					//$config['max_width'] = 1024;
	                //$config['max_height'] = 500;
	                $config['file_name'] = random_string('alnum', 16);

					$this->load->library('upload', $config);
					if (!$this->upload->do_upload('course_cover'))
					{
						$error = $this->upload->display_errors('<p>','</p>');

						c_flash('alert-danger',$error,'tutor/newcourse');

					}
					else
					{
						$filename = $this->upload->data();
						$data['course_cover'] = $filename['file_name'];
						$add_course = $this->mod_tutor->add_course($data);
						if ($add_course)
						{
							c_flash('alert-success','Your course has been added.','tutor/newcourse');
						}
						else
						{
							c_flash('alert-success','Oops something going wrong.','tutor/newcourse');
						}
						
					}

			}
			
		}
		
	}

	public function courses()
	{
		if (is_teacher())
		{

			$config = array();
			$config['first_link'] = FALSE;
			$config['first_tag_open'] = '<div class="first">';
			$config['first_tag_close'] = '</div>';
			$config['last_link'] = FALSE;
			$config['last_tag_open'] = '<div class="last">';
			$config['last_tag_close'] = '</div>';
			$config['next_link'] = ' <i class="fa fa-angle-double-right xyz"></i> ';
			$config['next_tag_open'] = '<span class="next">';
			
			$config['next_tag_close'] = '</span>';
			$config['prev_link'] = ' <i class="fa fa-angle-double-left yzx"></i> ';
			$config['next_tag_open'] = '<span class="prev">';
			$config['next_tag_close'] = '</span>';

			$config["base_url"] = base_url() ."tutor/courses";
			$user_id = $this->session->userdata('u_id');
			//die();
			$courses = $this->mod_tutor->get_all_courses($user_id);

			$config["total_rows"] = $courses->num_rows();
			$config["per_page"] = 50;//100;
			$config["uri_segment"] = 3;
			$this->load->library('pagination');
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
			$data["all_courses"] = $this->mod_tutor->
			fatch_allcourses($config["per_page"], $page,$user_id);

			$data["links"] = $this->pagination->create_links();
			$data['title'] =  'Admin - Add Categories | PapaGames';

			$this->load->view('tutor/header/header',$data);
			$this->load->view('tutor/css/css');
			$this->load->view('tutor/navbar/navbartop');
			$this->load->view('tutor/navbar/navbar_left');
			$this->load->view('tutor/content/courses');
			$this->load->view('tutor/footer/footer');
			//$this->load->view('tutor/js/admin_extrajs');			
			$this->load->view('tutor/js/js');	
		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','admin/login');
		}
	}




	public function editcourse($value)
	{
		if (is_teacher())
		{
			//echo $value;
			//die();
			$data['course'] = $this->mod_tutor->check_tut_course(user_id(),$value);
			if (empty($value))
			{
				c_flash('alert-warning','Oops something going wrong please try again.','tutor/courses');
			}
			else
			{
				if (count($data['course']) == 1)
				{
					$data['title'] =  'Add Courses | shakzee';
					$this->load->view('tutor/header/header',$data);
					$this->load->view('tutor/css/css');
					$this->load->view('tutor/navbar/navbartop');
					$this->load->view('tutor/navbar/navbar_left');
					$this->load->view('tutor/content/editcourse',$data);
					$this->load->view('tutor/footer/footer');
					//$this->load->view('tutor/js/admin_extrajs');			
					$this->load->view('tutor/js/js');	

				}
				else
				{
					c_flash('alert-warning','Course not Found.','tutor/courses');
					
				}
			}
			
			
		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','admin/login');
		}
	}



	public function courseedit()
	{
		$data['course_name'] = $this->input->post('coursename',TRUE);
		$data['course_desc'] = $this->input->post('coursedesc',TRUE);
		$data['course_level'] = $this->input->post('courselevel',TRUE);
		$data['course_type'] = $this->input->post('coursetype',TRUE);
		$data['c_views'] = $this->input->post('courseview',TRUE);

		$data['user_id'] = $this->session->userdata('u_id'); 
		$old_image = $this->input->post('xp5',TRUE);
		$course_id = $this->input->post('xp4',TRUE);
		$course_id = $this->encrypt->decode($course_id);
		$data['course_date'] = date_time();
		if (
				empty($data['course_name']) || empty($data['course_desc']) ||
				empty($data['course_level']) || empty($data['course_type']) || empty($course_id)
			)
		{
			c_flash('alert-warning','Please check required fields and try again.','tutor/editcourse/'.$course_id);
		}
		else 
		{


			if (isset($_FILES['course_cover']) && is_uploaded_file($_FILES['course_cover']['tmp_name'])) 
				{
					$image_path = realpath(APPPATH . '../assets/images/courses');
					$config['upload_path'] = $image_path;
					$config['allowed_types'] = 'gif|jpg|png';
					$config['max_size']	= '20000';
					//$config['max_width'] = 1024;
	                //$config['max_height'] = 500;
	                $config['file_name'] = random_string('alnum', 16);

					$this->load->library('upload', $config);
					if (!$this->upload->do_upload('course_cover'))
					{
						$error = $this->upload->display_errors('<p>','</p>');

						c_flash('alert-danger',$error,'tutor/editcourse/'.$course_id);

					}
					else
					{
						if (file_exists($image_path.'/'.$old_image))
						{
							 unlink($image_path.'/'.$old_image);
						}

						$filename = $this->upload->data();
						$data['course_cover'] = $filename['file_name'];
					}

				}//checking if cover updated.


				$courseedit = $this->mod_tutor->courseedit($course_id,$data);
				if ($courseedit)
				{
					c_flash('alert-success','Your course has been updated.','tutor/editcourse/'.$course_id);
				}
				else
				{
					c_flash('alert-success','Oops something going wrong.','tutor/editcourse/'.$course_id);
				}
			
			/*$check_user = $this->mod_tutor->chck_course($data);
			if ($check_user->num_rows() > 0)
			{
				c_flash('alert-warning','This course ' . $data['course_name'] . ' already exist.','tutor/editcourse/'.$course_id);
			}
			else
			{

				

			}*/
			
		}
		
	}


	public function newvideo()
	{
		if (is_teacher())
		{
			$user_id = user_id();
			$data['all_courses'] = $this->mod_tutor->get_all_courses($user_id);
			if ($data['all_courses']->num_rows() > 0) 
			{
				$data['title'] =  'Add video | shakzee';
				$this->load->view('tutor/header/header',$data);
				$this->load->view('tutor/css/css');
				$this->load->view('tutor/css/timepicker');
				$this->load->view('tutor/navbar/navbartop');
				$this->load->view('tutor/navbar/navbar_left');
				$this->load->view('tutor/content/newvideo',$data);
				$this->load->view('tutor/footer/footer');
				$this->load->view('tutor/js/timepickerjs');
				//$this->load->view('tutor/js/admin_extrajs');			
				$this->load->view('tutor/js/js');	

			}
			else
			{
				c_flash('alert-warning','First create a course to create a video/lecture','tutor/newcourse');
			}
			
		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','admin/login');
		}	
	}

	public function addvideo()
	{
		if (is_teacher())
		{
			$data['course_id'] = $this->input->post('course',TRUE);
			$data['v_duration'] = $this->input->post('duration',TRUE);
			$data['video_name'] = $this->input->post('video_name',TRUE);
			$data['video_cat'] = $this->input->post('vicat',TRUE);
			$videolink = $this->input->post('video_link',TRUE);

			if (
				empty($data['course_id']) || empty($videolink) ||
				empty($data['v_duration']) || empty($data['video_cat'])
				)
			{
				c_flash('alert-warning','Please check required fields and try again.','tutor/newvideo');
			}
			else
			{
				switch ($data['video_cat'])
				{
					case 'youtube':
								$data['y_link'] = $this->input->post('video_link',TRUE);
						break;
					case 'dailymotion':
								$data['d_link'] = $this->input->post('video_link',TRUE);
						break;
					default:
						c_flash('alert-warning','Please check required fields and try again.','tutor/newvideo');
						break;
				}//checking video category

				$data['user_id'] = user_id(); 
				$data['v_date'] = date_time(); 
				// var_dump($data);
				// die();
				$check_video = $this->mod_tutor->check_video($data);
				if ($check_video->num_rows() > 0)
				{
					c_flash('alert-warning','This Video\'s link : ' . $data['dailymotion'] . ' already exist.','tutor/newvideo');

				}
				else
				{
					$addvideo = $this->mod_tutor->addvideo($data);
					if ($addvideo)
					{
						c_flash('alert-success','Video\'s link : ' . $data['dailymotion'] . ' has been inserted.','tutor/newvideo');

					}
					else 
					{
						c_flash('alert-success','Oops something going wrong please try again.','tutor/newvideo');

					}

					
				}
				
			}
			


		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','admin/login');
		}	
		
	}


	public function videos()
	{
		if (is_teacher())
		{

			$config = array();
			$config['first_link'] = FALSE;
			$config['first_tag_open'] = '<div class="first">';
			$config['first_tag_close'] = '</div>';
			$config['last_link'] = FALSE;
			$config['last_tag_open'] = '<div class="last">';
			$config['last_tag_close'] = '</div>';
			$config['next_link'] = ' <i class="fa fa-angle-double-right xyz"></i> ';
			$config['next_tag_open'] = '<span class="next">';
			
			$config['next_tag_close'] = '</span>';
			$config['prev_link'] = ' <i class="fa fa-angle-double-left yzx"></i> ';
			$config['next_tag_open'] = '<span class="prev">';
			$config['next_tag_close'] = '</span>';

			$config["base_url"] = base_url() ."tutor/videos";
			$user_id = $this->session->userdata('u_id');
			//die();
			$courses = $this->mod_tutor->get_all_videos($user_id);

			$config["total_rows"] = $courses->num_rows();
			$config["per_page"] = 30;//100;
			$config["uri_segment"] = 3;
			$this->load->library('pagination');
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
			$data["all_videos"] = $this->mod_tutor->
			fatch_all_videos($config["per_page"], $page,$user_id);

			$data["links"] = $this->pagination->create_links();
			$data['title'] =  'Admin - Add Categories | PapaGames';

			$this->load->view('tutor/header/header',$data);
			$this->load->view('tutor/css/css');
			$this->load->view('tutor/navbar/navbartop');
			$this->load->view('tutor/navbar/navbar_left');
			$this->load->view('tutor/content/videos',$data);
			$this->load->view('tutor/footer/footer');
			//$this->load->view('tutor/js/admin_extrajs');			
			$this->load->view('tutor/js/js');	
		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','admin/login');
		}
	}

	public function editvideo($value)
	{
		if (is_teacher())
		{
			//echo $value;
			//die();
			$user_id = user_id();
			$data['all_courses'] = $this->mod_tutor->get_all_courses($user_id);
			$data['video'] = $this->mod_tutor->check_tut_video($user_id,$value);
			if (empty($value))
			{
				c_flash('alert-warning','Oops something going wrong please try again.','tutor/videos');
			}
			else
			{
				if (count($data['video']) == 1)
				{
					$data['title'] =  'Add Courses | shakzee';
					$this->load->view('tutor/header/header',$data);
					$this->load->view('tutor/css/css');
					$this->load->view('tutor/navbar/navbartop');
					$this->load->view('tutor/navbar/navbar_left');
					$this->load->view('tutor/content/editvideo',$data);
					$this->load->view('tutor/footer/footer');
					//$this->load->view('tutor/js/admin_extrajs');			
					$this->load->view('tutor/js/js');	

				}
				else
				{
					c_flash('alert-warning','Course not Found.','tutor/videos');
					
				}
			}
			
			
		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','admin/login');
		}
	}




	public function updatevideo()
	{
		if (is_teacher())
		{
			$data['course_id'] = $this->input->post('course',TRUE);
			$data['v_duration'] = $this->input->post('duration',TRUE);
			$data['video_name'] = $this->input->post('video_name',TRUE);
			
			$data['video_cat'] = $this->input->post('vicat',TRUE);
			$videolink = $this->input->post('video_link',TRUE);

			$video_id = $this->input->post('v_x_i',TRUE);

			if (
					empty($data['course_id']) || empty($videolink) ||
					empty($data['v_duration']) || empty($data['video_cat']) || empty($video_id)
				)
			{
				c_flash('alert-warning','Please check required fields and try again.','tutor/videos');
			}
			else
			{
				switch ($data['video_cat'])
				{
					case 'youtube':
								$data['y_link'] = $this->input->post('video_link',TRUE);
						break;
					case 'dailymotion':
								$data['d_link'] = $this->input->post('video_link',TRUE);
						break;
					default:
						c_flash('alert-warning','Please check required fields and try again.','tutor/newvideo');
						break;
				}//checking video category
				$data['user_id'] = user_id(); 
				$data['v_date'] = date_time(); 
				// var_dump($data);
				// die();
				$update_video = $this->mod_tutor->update_video($data,$video_id);
					if ($update_video)
					{
						c_flash('alert-success','Video\'s link : ' . $data['dailymotion'] . ' has been inserted.','tutor/videos');

					}
					else 
					{
						c_flash('alert-success','Oops something going wrong please try again.','tutor/videos');

					}
				/*$check_video = $this->mod_tutor->check_video($data);
				if ($check_video->num_rows() > 0)
				{
					c_flash('alert-warning','This Video\'s link : ' . $data['dailymotion'] . ' already exist.','tutor/videos');

				}
				else
				{
					

					
				}*/
				
			}
			


		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','admin/login');
		}	
	}

	public function procourses()
	{
		if (is_teacher())
		{

			$config = array();
			$config['first_link'] = FALSE;
			$config['first_tag_open'] = '<div class="first">';
			$config['first_tag_close'] = '</div>';
			$config['last_link'] = FALSE;
			$config['last_tag_open'] = '<div class="last">';
			$config['last_tag_close'] = '</div>';
			$config['next_link'] = ' <i class="fa fa-angle-double-right xyz"></i> ';
			$config['next_tag_open'] = '<span class="next">';
			
			$config['next_tag_close'] = '</span>';
			$config['prev_link'] = ' <i class="fa fa-angle-double-left yzx"></i> ';
			$config['next_tag_open'] = '<span class="prev">';
			$config['next_tag_close'] = '</span>';

			$config["base_url"] = base_url() ."tutor/procourses";
			$user_id = user_id(); 
			//$this->session->userdata('u_id');
			//die();
			$courses = $this->mod_tutor->get_all_pro_courses($user_id);

			$config["total_rows"] = $courses->num_rows();
			$config["per_page"] = 30;//100;
			$config["uri_segment"] = 3;
			$this->load->library('pagination');
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
			$data["all_pro_courses"] = $this->mod_tutor->
			fatch_all_pro_courses($config["per_page"], $page,$user_id);

			$data["links"] = $this->pagination->create_links();
			$data['title'] =  'Admin - Add Categories | PapaGames';

			$this->load->view('tutor/header/header',$data);
			$this->load->view('tutor/css/css');
			$this->load->view('tutor/navbar/navbartop');
			$this->load->view('tutor/navbar/navbar_left');
			$this->load->view('tutor/content/procourses',$data);
			$this->load->view('tutor/footer/footer');
			//$this->load->view('tutor/js/admin_extrajs');			
			$this->load->view('tutor/js/js');	
		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','admin/login');
		}
	}

	public function getprocourse($value)
	{
		if (is_teacher())
		{
			//echo $value;
			//die();
			$teacher_id = user_id();
			$data['all_courses'] = $this->mod_tutor->get_all_courses($teacher_id);
			$data['courses'] = $this->mod_tutor->check_pro_course($teacher_id,$value);
			if (empty($value))
			{
				c_flash('alert-warning','Oops something going wrong please try again.','tutor/procourses');
			}
			else
			{
				if (count($data['courses']) == 1)
				{


					$data['title'] =  'Add Courses | shakzee';
					$this->load->view('tutor/header/header',$data);
					$this->load->view('tutor/css/css');
					$this->load->view('tutor/css/froala_editor');

					$this->load->view('tutor/navbar/navbartop');
					$this->load->view('tutor/navbar/navbar_left');
					$this->load->view('tutor/content/getprocourse',$data);
					//$this->load->view('tutor/content/editvideo',$data);
					$this->load->view('tutor/footer/footer');
					$this->load->view('tutor/js/froala_editor');
					//$this->load->view('tutor/js/admin_extrajs');			
					$this->load->view('tutor/js/js');	

				}
				else
				{
					c_flash('alert-warning','Course not Found.','tutor/procourses');
					
				}
			}
			
			
		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','admin/login');
		}
	}


	public function updateprocourse()
	{
		if (is_teacher())
		{
			$old_id = $this->input->post('x_di',TRUE);
			$old_img = $this->input->post('x_pi',TRUE);
			
			$data['uc_coursename'] =  $this->input->post('coursename',TRUE);
			$data['uc_detail'] =  $this->input->post('coursedesc',TRUE);
			$data['uc_required_course'] =  $this->input->post('courserequired',TRUE);
			$data['uc_day_from'] =  $this->input->post('dayfrom',TRUE);
			$data['uc_day_to'] =  $this->input->post('dayto',TRUE);
			$data['uc_level'] =  $this->input->post('courselevel',TRUE);
			$data['uc_duration'] =  $this->input->post('duration',TRUE);
			$data['uc_course'] =  $this->input->post('where',TRUE);
			$data['uc_fess'] =  $this->input->post('fess',TRUE);
			$data['teacher_id'] = user_id();
			if (
				 empty($data['uc_coursename']) || empty($data['uc_detail']) || empty($data['uc_required_course']) || empty($data['uc_day_from']) || empty($data['uc_day_to']) || 
				 empty($data['uc_level']) || empty($data['uc_duration']) || empty($data['uc_course']) || empty($data['uc_fess'])
				 || empty($old_id) || empty($old_img)

				)
			{
				c_flash('alert-warning','Please select a course to view detail.','tutor/newprocourse');
			}
			else
			{
				$old_id = $this->encrypt->decode($old_id);
				$check_procourse = $this->mod_tutor->check_procourse($data,$old_id);
				if ($check_procourse->num_rows() === 1)
				{
						if (isset($_FILES['course_cover']) && is_uploaded_file($_FILES['course_cover']['tmp_name'])) 
						{
							$image_path = realpath(APPPATH . '../assets/images/p_courses');
							$config['upload_path'] = $image_path;
							$config['allowed_types'] = 'gif|jpg|png';
							//$config['max_size']	= '10000';
							//$config['max_width'] = 1024;
			                //$config['max_height'] = 500;
			                $config['file_name'] = random_string('alnum', 16);
			                					$this->load->library('upload', $config);
							if (!$this->upload->do_upload('course_cover'))
							{
								$error = $this->upload->display_errors('<p>','</p>');

								c_flash('alert-danger',$error,'tutor/newprocourse');

							}
							else
							{
								$filename = $this->upload->data();
								$data['uc_cover'] = $filename['file_name'];
								if (file_exists($image_path.'/'.$old_img))
								{
									 unlink($image_path.'/'.$old_img);
								}
								
							}
						}
						$updateprocourse = $this->mod_tutor->updateprocourse($data,$old_id);
						if ($updateprocourse)
						{
							c_flash('alert-success','Your course <strong> ' . $data['uc_coursename'] . '</strong> has been added successfully.' ,'tutor/procourses');
						}
						else
						{
							c_flash('alert-success','Your course <strong> ' . $data['uc_coursename'] . '</strong> has not been added.' ,'tutor/procourses');
						}					
				}
				else
				{
					c_flash('alert-warning','Course not available','tutor/newprocourse');
				}



			}
			
		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','admin/login');
		}

	}//function ends here

/*	public function newblog()
	{
		if (is_teacher())
		{
			$data['title'] =  'Add Courses | shakzee';
			$this->load->view('tutor/header/header',$data);
			$this->load->view('tutor/css/css');
			$this->load->view('tutor/navbar/navbartop');
			$this->load->view('tutor/navbar/navbar_left');
			$this->load->view('tutor/content/newblog');
			$this->load->view('tutor/footer/footer');
			//$this->load->view('tutor/js/admin_extrajs');			
			$this->load->view('tutor/js/js');	
	
		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','admin/login');
		}
	}
*/
	public function addblog()
	{
		if (is_teacher())
		{
			$data['b_title'] =  $this->input->post('blog_title',TRUE);
			$data['blog'] = $this->input->post('blog',TRUE);
			$blog_tags = $this->input->post('blog_tags',TRUE);
			$data['user_id'] = user_id();
			if (
				 empty($data['b_title']) || empty($data['blog']) || 
				 empty($blog_tags)

				)
			{
				c_flash('alert-warning','Please check reuired fields and try again.','tutor/newblog');
			}
			else 
			{

				$blog_id = $this->mod_tutor->addblog();
				if (is_integer($blog_id))
				{
					if (count($blog_tags) == 1)
					{
						$log_tags = array(
										'blog_id'=>$blog_id,
										't_created'=> date_time(),
										'tname'=>$blog_tags[0],
										 );
						$insert_blog_tags = $this->mod_tutor->insert_blog_tags($log_tags);
						if ($insert_blog_tags)
						{
							//echo 'insert hogya blog';
							c_flash('alert-success','Your blog has been inserted.','tutor/newblog');

						}
						else
						{
							//echo 'blog insert nahen hua..';
							c_flash('alert-warning','Oops something going wrong..! your blogs not inserted.','tutor/newblog');
						}
						
					}	
					else if(count($blog_tags) > 1)
					{
						$blogtags = array(); 
					        		foreach ($blog_tags as $tag)
					        		{
					        			$blogtags[] = array(
						        			'blog_id'=>$addblog,
						        			't_name'=>$tag,
						        			't_created'=> date_time()
					        				);
					        		}

					    $insertfaci = $this->mod_tutor->insert_blog_tags_batch($blogtags);
					    //echo 'insert batch insert hogya..';
						c_flash('alert-success','Your blog has been inserted.','tutor/newblog');

					}

				}//if blog inserted empty
		    }//if empty	
		}//is teacher
		else 
		{
			c_flash('alert-warning','Your are not a teacher.','admin/login');
		}
		
	}//function ends here

	public function newprocourse()
	{
		if (is_teacher())
		{
			$data['title'] =  'Add Courses | shakzee';
			$this->load->view('tutor/header/header',$data);
			$this->load->view('tutor/css/css');
			$this->load->view('tutor/css/froala_editor');

			$this->load->view('tutor/navbar/navbartop');
			$this->load->view('tutor/navbar/navbar_left');
			$this->load->view('tutor/content/newprocourse');
			$this->load->view('tutor/footer/footer');
			$this->load->view('tutor/js/froala_editor');
			//$this->load->view('tutor/js/admin_extrajs');			
			$this->load->view('tutor/js/js');	
		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','admin/login');
		}

	}

	public function addprocourse()
	{
		if (is_teacher())
		{
			$data['uc_coursename'] =  $this->input->post('coursename',TRUE);
			$data['uc_detail'] =  $this->input->post('coursedesc',TRUE);
			$data['uc_required_course'] =  $this->input->post('courserequired',TRUE);
			$data['uc_day_from'] =  $this->input->post('dayfrom',TRUE);
			$data['uc_day_to'] =  $this->input->post('dayto',TRUE);
			$data['uc_level'] =  $this->input->post('courselevel',TRUE);
			$data['uc_duration'] =  $this->input->post('duration',TRUE);
			$data['uc_course'] =  $this->input->post('where',TRUE);
			$data['uc_fess'] =  $this->input->post('fess',TRUE);
			$data['teacher_id'] = user_id();
			$data['uc_date'] = date_time();
			if (
				 empty($data['uc_coursename']) || empty($data['uc_detail']) || empty($data['uc_required_course']) || empty($data['uc_day_from']) || empty($data['uc_day_to']) || 
				 empty($data['uc_level']) || empty($data['uc_duration']) || empty($data['uc_course']) || empty($data['uc_fess'])
				)
			{
				c_flash('alert-warning','Please select a course to view detail.','tutor/newprocourse');
			}
			else
			{
				if (isset($_FILES['course_cover']) && is_uploaded_file($_FILES['course_cover']['tmp_name'])) 
				{
					$image_path = realpath(APPPATH . '../assets/images/p_courses');
					$config['upload_path'] = $image_path;
					$config['allowed_types'] = 'gif|jpg|png';
					//$config['max_size']	= '10000';
					//$config['max_width'] = 1024;
	                //$config['max_height'] = 500;
	                $config['file_name'] = random_string('alnum', 16);
	                					$this->load->library('upload', $config);
					if (!$this->upload->do_upload('course_cover'))
					{
						$error = $this->upload->display_errors('<p>','</p>');

						c_flash('alert-danger',$error,'tutor/newprocourse');

					}
					else
					{
						$filename = $this->upload->data();
						$data['uc_cover'] = $filename['file_name'];
					}

					$addprocourse = $this->mod_tutor->addprocourse($data);
					if ($addprocourse)
					{
						c_flash('alert-success','Your course <strong> ' . $data['uc_coursename'] . '</strong> has been added successfully.' ,'tutor/newprocourse');
					}
					else
					{
						c_flash('alert-success','Your course <strong> ' . $data['uc_coursename'] . '</strong> has not been added.' ,'tutor/newprocourse');
					}
					
				}
				else
				{
					c_flash('alert-warning','Please check your course pic and try again.','tutor/newprocourse');
				}

			}
			
		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','login');
		}
		

	}

	public function settings()
	{
		if (is_teacher())
		{
			echo 'setting shere';
		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','login');
		}
		
	}

	public function logout()
	{
		if (is_logedin())
		{
			$this->session->sess_destroy();
			redirect('home');
		}
		else
		{
			redirect('home');
		}
	}

	public function ip()
	{
		$ip = $this->session->all_userdata();
		var_dump($ip);

	}



		public function newcategory()
	{
		if (is_teacher())
		{
			$data['title'] =  'Add Courses | shakzee';
			$this->load->view('tutor/header/header',$data);
			$this->load->view('tutor/css/css');
			$this->load->view('tutor/navbar/navbartop');
			$this->load->view('tutor/navbar/navbar_left');
			$this->load->view('tutor/content/newcategory');
			$this->load->view('tutor/footer/footer');
			//$this->load->view('tutor/js/admin_extrajs');			
			$this->load->view('tutor/js/js');
		}
		else
		{

		}
		
	}


	public function add_blog_category()
	{
		if (is_teacher())
		{
			$data['bc_name'] = $this->input->post('category',TRUE);
			$data['bc_created'] = date("Y-m-d h:i:sa");
			$data['user_id'] = user_id();
			if (empty($data['bc_name']))
			{
				c_flash('alert-warning','Please check required fields and try again.','tutor/newcategory');
			}
			else
			{
				$check = $this->mod_tutor->check_blog_category($data);
				if ($check->num_rows() > 0)
				{
					c_flash('alert-warning','This Category<strong> ' . $data['bc_name'] . ' </strong> is already exist.','tutor/newcategory');
				}
				else
				{
					$add_blog_cat = $this->mod_tutor->add_blog_category($data);
					if ($add_blog_cat)
					{
						c_flash('alert-success','Your Category <strong> ' . $data['bc_name'] . ' </strong>  has been inserted.' ,'tutor/newcategory');
					}
					else
					{
						c_flash('alert-warning','Your Category <strong> ' . $data['bc_name'] . ' </strong>  has not been inserted.' ,'tutor/newcategory');
					}//else add blog
					
				}//else check blog

			}//else empty
			
		}
		else
		{
			c_flash('alert-warning','Please login first.','login');
		}//else admin logedin

	}

	public function all_blog_categories()
	{
		if (is_teacher())
		{
			$config = array();
			$config['first_link'] = FALSE;
			$config['first_tag_open'] = '<div class="first">';
			$config['first_tag_close'] = '</div>';
			$config['last_link'] = FALSE;
			$config['last_tag_open'] = '<div class="last">';
			$config['last_tag_close'] = '</div>';
			$config['next_link'] = ' <i class="fa fa-angle-double-right xyz"></i> ';
			$config['next_tag_open'] = '<span class="next">';
			
			$config['next_tag_close'] = '</span>';
			$config['prev_link'] = ' <i class="fa fa-angle-double-left yzx"></i> ';
			$config['next_tag_open'] = '<span class="prev">';
			$config['next_tag_close'] = '</span>';

			$config["base_url"] = base_url() ."tutor/all_blog_categories";
	
			$modals = $this->mod_tutor->getall_blog_categories();

			$config["total_rows"] = $modals->num_rows();
			$config["per_page"] = 40;//100;
			$config["uri_segment"] = 3;
			$this->load->library('pagination');
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
			$data["all_blog_categories"] = $this->mod_tutor->
			fatch_blog_categories($config["per_page"], $page);

			$data["links"] = $this->pagination->create_links();
			$data['title'] =  'Add Courses | shakzee';
			
			$this->load->view('tutor/header/header',$data);
			$this->load->view('tutor/css/css');
			$this->load->view('tutor/navbar/navbartop');
			$this->load->view('tutor/navbar/navbar_left');
			$this->load->view('tutor/content/blog_categories');
			$this->load->view('tutor/footer/footer');
			$this->load->view('tutor/js/js');
		}
		else
		{
			c_flash('alert-warning','Please login first.','login');
		}
		
	}


	public function edit_blog_category($id)
	{
		if (is_teacher())
		{
			if (!empty($id))
			{
				$data['blog_category'] = $this->mod_tutor->check_blog_catid($id);
				if (count($data['blog_category']) >  0 )
				{
					$this->load->view('tutor/header/header',$data);
					$this->load->view('tutor/css/css');
					$this->load->view('tutor/navbar/navbartop');
					$this->load->view('tutor/navbar/navbar_left');
					$this->load->view('tutor/content/edit_blog_category');
					$this->load->view('tutor/footer/footer');
					$this->load->view('tutor/js/js');				

					// $data['title'] =  'Admin - Add Modal | PapaGames';
					// $this->load->view('admin/header/header',$data);
					// $this->load->view('admin/css/css');
					// $this->load->view('admin/navbar/navbartop');
					// $this->load->view('admin/navbar/navbar_left');
					// $this->load->view('admin/content/edit_blog_category',$data);
					// $this->load->view('admin/footer/footer');
					// $this->load->view('admin/js/js');
				}
				else
				{
					c_flash('alert-warning','Please login first.','login');
				}
				
			}
			else
			{//else not empty
				c_flash('alert-warning','Please login first.','login');
			}
			
		}
		else
		{
			c_flash('alert-warning','Please login first.','login');
		}
	}


	/*public function newblog()
	{
		if (is_teacher())
		{
			if (!empty($id))
			{
				$data['blog_category'] = $this->mod_tutor->check_blog_catid($id);
				if (count($data['blog_category']) >  0 )
				{
					$this->load->view('tutor/header/header',$data);
					$this->load->view('tutor/css/css');
					$this->load->view('tutor/navbar/navbartop');
					$this->load->view('tutor/navbar/navbar_left');
					$this->load->view('tutor/content/newblog');
					$this->load->view('tutor/footer/footer');
					$this->load->view('tutor/js/js');				

				}
				else
				{
					c_flash('alert-warning','Please login first.','login');
				}
				
			}
			else
			{//else not empty
				c_flash('alert-warning','Please login first.','login');
			}
			
		}
		else
		{
			c_flash('alert-warning','Please login first.','login');
		}
	}*/

	public function newblog()
	{
		if (is_teacher())
		{
				$data['title'] =  'Admin - Add Modal | PapaGames';
				$data['b_cat'] = $this->mod_tutor->get_blog_categories();
				$this->load->view('tutor/header/header',$data);
				$this->load->view('tutor/css/css');
				$this->load->view('tutor/css/froala_editor');
				$this->load->view('tutor/navbar/navbartop');
				$this->load->view('tutor/navbar/navbar_left');
				$this->load->view('tutor/content/newblog');
				$this->load->view('tutor/footer/footer');
				$this->load->view('tutor/js/froala_editor');
				$this->load->view('tutor/js/js');
		}
		else
		{
			c_flash('alert-warning','Please login first.','login');
		}
		
	}

	public function adddblog()
	{
		if (is_teacher())
		{
			$data['blog_title'] = $this->input->post('b_name',true);
			$data['bcat_id'] = $this->input->post('category',true);
			$data['blog'] = base64_encode($this->input->post('blog',true));
			$data['user_id'] = user_id();
			$data['b_created'] = date("Y-m-d h:i:sa");

			$tags = $this->input->post('tags',true);
			//$data[''] = $this->input->post('bdp',true);
			/*var_dump($tags);
			die();*/
			if (
					empty($data['blog_title']) || empty($data['blog']) || 
					empty($data['bcat_id']) /*count($tags) < 1*/
				)
			{
				//echo 'kuch khali ha..';
				c_flash('alert-error','Plse check required fields.','tutor/newblog');

			}//checkign if required fields empty
			else
			{
				$image_path = realpath(APPPATH . '../assets/images/blogs');

		        $bdp = $this->myupload($image_path,'bdp');
		        if (!empty($bdp) && $bdp != false)
		        {
			   		$data['blog_cover'] =  $bdp['file_name'];
					$addblog = $this->mod_tutor->addblog($data);
					if (is_integer($addblog))
					{
						if (count($tags) > 1 && !empty($tags))
						{

							$blogtags = array(); 
					        		foreach ($tags as $tag)
					        		{
					        			$blogtags[] = array(
						        			'blog_id'=>$addblog,
						        			'tag_name'=>$tag,
						        			'tag_created'=> date("Y-m-d h:i:sa")
					        				);
					        		}

						    $insertfaci = $this->mod_tutor->insert_blog_tags_batch($blogtags);
						    if ($insertfaci)
						    {
						    	c_flash('alert-success','Your blog has been inserted.','tutor/newblog');
						    }
						    else
						    {
						    	c_flash('alert-error','Your blog has been inserted but we can\'t insert your tags right now.','tutor/newblog');
						    }
						    

						}
						else
						{
							c_flash('alert-success','Your blog has been inserted.','tutor/newblog');							
						}
					}//if blog insergted
					else//blog not inserted
					{
						c_flash('alert-error','cover not uploaded.','tutor/newblog');
					}
					
		        }//if pic uploaded
		        else//else pic not uploaded
		        {
		        	c_flash('alert-error','cover not uploaded.','tutor/newblog');
		        }

			}//else data exist			
		}//checking if user not logedin
		else
		{
			redirect('login');

		}
		
	}



	private function myupload($path,$userfile)
	{
		$config['upload_path'] = $path;
        $config['allowed_types'] = 'png|jpg|jpeg|gif|bmp';
        $config['file_name'] = date("Ymd") . time();
        $config['overwrite'] = true;
        $config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']= '10000';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        if(!$this->upload->do_upload($userfile))
        {
        	return False;
			// $this->upload->display_errors();
		}
		else
		{
			return $this->upload->data();
		} 

	}


	public function all_blogs()
	{
		if (is_teacher())
		{
			$config = array();
			$config['first_link'] = FALSE;
			$config['first_tag_open'] = '<div class="first">';
			$config['first_tag_close'] = '</div>';
			$config['last_link'] = FALSE;
			$config['last_tag_open'] = '<div class="last">';
			$config['last_tag_close'] = '</div>';
			$config['next_link'] = ' <i class="fa fa-angle-double-right xyz"></i> ';
			$config['next_tag_open'] = '<span class="next">';
			
			$config['next_tag_close'] = '</span>';
			$config['prev_link'] = ' <i class="fa fa-angle-double-left yzx"></i> ';
			$config['next_tag_open'] = '<span class="prev">';
			$config['next_tag_close'] = '</span>';

			$config["base_url"] = base_url() ."tutor/all_blogs";
	
			$modals = $this->mod_tutor->getall_blogs();

			$config["total_rows"] = $modals->num_rows();
			$config["per_page"] = 40;//100;
			$config["uri_segment"] = 3;
			$this->load->library('pagination');
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
			$data["all_blog_categories"] = $this->mod_tutor->
			fatch_blogs($config["per_page"], $page);

			$data["links"] = $this->pagination->create_links();
			$data['title'] =  'Admin -All Blogs';
				$this->load->view('tutor/header/header',$data);
				$this->load->view('tutor/css/css');
				$this->load->view('tutor/navbar/navbartop');
				$this->load->view('tutor/navbar/navbar_left');
				$this->load->view('tutor/content/all_blogs');
				$this->load->view('tutor/footer/footer');
				$this->load->view('tutor/js/js');
		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','login');
		}
		
	}


	public function edit_blog($id)
	{
		if (is_teacher())
		{
			if (!empty($id))
			{
				$data['dblog'] = $this->mod_tutor->check_blog($id);
				//echo count($data['blog']);
				$data['blog_tags'] = $this->mod_tutor->get_blog_tags($data['dblog'][0]['b_id']);
				//die();
				if (count($data['dblog']) >  0 )
				{
					$data['title'] =  'Admin - Add Modal | PapaGames';
					$data['b_cat'] = $this->mod_tutor->get_blog_categories();
					$this->load->view('tutor/header/header',$data);
					$this->load->view('tutor/css/css');
					$this->load->view('tutor/css/froala_editor');
					$this->load->view('tutor/navbar/navbartop');
					$this->load->view('tutor/navbar/navbar_left');
					$this->load->view('tutor/content/edit_blog');
					$this->load->view('tutor/footer/footer');
					$this->load->view('tutor/js/froala_editor');
					$this->load->view('tutor/js/js');
				}
				else
				{
					c_flash('alert-warning','Please login first.','tutor/login');
				}
			}
			else
			{//else not empty
				c_flash('alert-warning','Please login first.','tutor/login');
			}

		}
		else
		{
			c_flash('alert-warning','Your are not a teacher.','login');
		}
		
	}



	public function deletetag()
	{
		if ($this->input->is_ajax_request())
		{
			$dtext = $this->input->post('dtxt',TRUE);
			$this->input->post('di',TRUE);
			if (!empty($dtext))
			{
				$dtext = $this->encrypt->decode($dtext);
				$deletetag = $this->mod_tutor->deletetag($dtext);
				 if ($deletetag)
				 {
				 	$data['return'] = TRUE;
				 	echo json_encode($data);
				 }
				 else
				 {

				 	$data['return'] = FALSE;
				 	$data['message'] = 'We can\'t remove your tag right now please try again.';
				 	echo json_encode($data);
				 }
				 
			}	
			else
			{
				$data['message'] = 'Please check required fields and try again.';
				echo json_encode($data);
			}
		}
		else
		{
			c_flash('alert-danger','Category Not Available','notfound');
		}

	}

	public function updatedblog()
	{
		if (is_teacher())
		{
			$data['blog_title'] = $this->input->post('b_name',true);
			$data['bcat_id'] = $this->input->post('category',true);
			$data['blog'] = base64_encode($this->input->post('blog',true));
			$data['user_id'] = user_id();
			$blogid = $this->input->post('yup',true);
			$oldimg = $this->input->post('yig',true);
			$tags = $this->input->post('tags',true);

			//$data[''] = $this->input->post('bdp',true);
			//die();
			if (
					empty($data['blog_title']) || empty($data['blog']) || 
					empty($data['bcat_id']) || empty($blogid) || empty($oldimg)
				)
			{
				//echo 'kuch khali ha..';
				c_flash('alert-error','Plse check required fields.','tutor/newblog');

			}//checkign if required fields empty
			else
			{
				/*var_dump($tags);
				die();*/
				$blogid = $this->encrypt->decode($blogid);
				$oldimg = $this->encrypt->decode($oldimg);

				$image_path = realpath(APPPATH . '../assets/images/blogs');
				if (isset($_FILES['bdp']) && is_uploaded_file($_FILES['bdp']['tmp_name'])) 
				{

				        $bdp = $this->myupload($image_path,'bdp');
				        if (!empty($bdp) && $bdp != false)
				        {
					   		$data['blog_cover'] =  $bdp['file_name'];
							
				        }//if pic uploaded
				        else//else pic not uploaded
				        {
				        	c_flash('alert-error','cover not uploaded.','tutor/edit_blog/'.$blogid);
				        }
				}//if img selected

				$updateblog = $this->mod_tutor->updateblog($data,$blogid);
						if ($updateblog)
						{
								if (file_exists($image_path.'/'.$oldimg))
								{
									unlink($image_path.'/'.$oldimg);
								}

								if (count($tags) > 0 && !empty($tags))
								{

									$blogtags = array(); 
							        		foreach ($tags as $tag)
							        		{
							        			$blogtags[] = array(
								        			'blog_id'=>$blogid,
								        			'tag_name'=>$tag,
								        			'tag_created'=> date("Y-m-d h:i:sa")
							        				);
							        		}

								    $insertfaci = $this->mod_user->insert_blog_tags_batch($blogtags);
								    if ($insertfaci)
								    {
								    	c_flash('alert-success','Your blog has been updated.','tutor/all_blogs');
								    }
								    else
								    {
								    	c_flash('alert-error','Your blog has been updated but we can\'t insert your tags right now.','tutor/newblog');
								    }
								    

								}//if tags exist
								else
								{
									c_flash('alert-success','Your blog has been updated.','tutor/newblog');							
								}
						}//if blog updated
						else//blog not inserted
						{
							c_flash('alert-error','cover not uploaded.','tutor/newblog');
						}

			}//else data exist			
		}//checking if user not logedin
		else
		{
			redirect('login');

		}
		
	}
}//class ends here