    <!-- bootstrap time picker -->
    <script src="<?php echo base_url('assets/admin/plugins/timepicker/bootstrap-timepicker.min.js')?>"></script>
<script type="text/javascript">
    //Timepicker
     $(".timepicker").timepicker({
          showInputs: false,
          showMeridian:false
        });
	
</script>