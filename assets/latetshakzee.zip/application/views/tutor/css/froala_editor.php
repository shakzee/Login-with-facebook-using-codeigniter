
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/froala/css/froala_editor.min.css');?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/froala/css/froala_style.min.css');?>">
