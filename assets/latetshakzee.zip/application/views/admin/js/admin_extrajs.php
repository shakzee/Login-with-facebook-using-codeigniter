    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="<?php echo site_url('assets/admin/dist/js/pages/dashboard2.js')?>"></script>
