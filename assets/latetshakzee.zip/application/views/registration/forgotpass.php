

<div class="container">
	<table>
		<tr>
			<td>
				<img src="<?php echo base_url('assets/pics/shakzee-logo.png') ?>">
				<h3>Reset Password | <a href="http://www.shakzee.com">Shakzee</a></h3>
			</td>
		</tr>
		<tr>
			<td>
				<h3>Here is you confirmation code</h3>
				<p>Please Click below to Reset your Password.<p>
				<a href="<?php echo site_url('register/setpassword/').'/'.$password ;?>" title="Reset Your Email">
					<?php echo site_url('register/setpassword/').'/'.$password ;?>
				</a>
				<h3>If the above link doesn't work, copy and paste this address into your browser:</h3>
			</td>
		</tr>
		<tr>
			<td>
				<h3>Join Us On Social Networks</h3>
				<p>
					<a href="https://www.facebook.com/pages/Shakzee/924506674234189" title="join us on facebook">facebook</a>
				</p>
				<p>
					<a href="https://twitter.com/uShakzee" title="join us on twitter">Twitter</a>
				</p>

				<p>
					<a href="https://plus.google.com/u/0/b/102340252625280122990/102340252625280122990/posts" title="join us on g+">google Plus</a>
				</p>

				<p>Please inform us for further <a href="<?php echo site_url('contactus') ?>">help</a></p>
				<h2>Please do not reply to this message.</h2>
				<p>For further information visit <a href="<?php echo site_url('home'); ?>">www.shakzee.com</a></p>
			</td>
		</tr>
	</table>
</div>