<div class="container">
	<div class="row">
		<div class="col-md-7 col-md-offset-2">
			<div class="form-gorup">
				<?php c_error();?>
			</div>
			<div class="cnt_404">
				<img src="<?php echo base_url('assets/images/404/404-shakzee.jpg'); ?>" alt="Page not found" class="img-responsive">
			</div>
		</div>
	</div>
</div>