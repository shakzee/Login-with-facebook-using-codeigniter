
<section class="slider">
    <div class="fullwidthbanner-container">
        <div class="fullwidthbanner">
			<ul>
                <li data-transition="flyin" data-slotamount="1" data-masterspeed="300"  data-thumb="<?php echo base_url('assets/home/images/thumbs/thumb1.jpg') ?>" data-delay="4000" >
                    <img src="<?php echo base_url('assets/home/images/slides/slide-intro.png') ?>" alt="">
                    <!--<div class="caption randomrotate"
                    data-x="center"
                    data-y="120"
                    data-speed="300"
                    data-start="1200"
                    data-easing="easeOutExpo"  >
	                    <img src="<?php echo base_url('assets/images/250x60.png'); ?>" alt="">
                    </div>-->
                </li>
                <li data-transition="3dcurtain-horizontal" data-slotamount="1" data-masterspeed="300"  data-thumb="<?php echo base_url('assets/home/images/thumbs/thumb2.jpg') ?>">
                    <img src="<?php echo base_url('assets/home/images/slides/slide-1.jpg') ?>" alt="">
            
                   <div class="caption randomrotate"
                    data-x="center"
                    data-y="90"
                    data-speed="300"
                    data-start="1000"
                    data-easing="easeOutExpo"  >
                     	<img src="<?php echo base_url('assets/home/images/slides/diagram.png') ?>" alt="Image 9">
                    </div>

                    <div class="caption randomrotate"
                    data-x="170"
                    data-y="80"
                    data-speed="300"
                    data-start="2000"
                    data-easing="easeOutExpo"  >
                    	<img src="<?php echo base_url('assets/home/images/slides/icon-slide-1.png') ?>" alt="">
                    </div>

                    <div class="caption randomrotate"
					data-x="170"
					data-y="300"
					data-speed="300"
					data-start="2500"
					data-easing="easeOutExpo"  >
                        <img src="<?php echo base_url('assets/home/images/slides/icon-slide-2.png') ?>" alt="">
                    </div>

                    <div class="caption randomrotate"
					data-x="620"
					data-y="80"
					data-speed="300"
					data-start="3000"
					data-easing="easeOutExpo"  >
                        <img src="<?php echo base_url('assets/home/images/slides/icon-slide-3.png') ?>" alt="">
                    </div>

                    <div class="caption randomrotate"
					data-x="650"
					data-y="300"
					data-speed="300"
					data-start="3500"
					data-easing="easeOutExpo"  >
						<img src="<?php echo base_url('assets/home/images/slides/icon-slide-4.png') ?>" alt="">
					</div>
                </li>
                <!-- <li data-transition="3dcurtain-horizontal" data-slotamount="1" data-masterspeed="300"  data-thumb="<?php //echo base_url('assets/home/images/thumbs/thumb2.jpg') ?>">
                    <img src="<?php //echo base_url('assets/home/images/slides/slide-2.jpg') ?>" alt="">
					<div class="caption very_big_white lfl stl"
					data-x="right"
					data-y="180"
					data-speed="300"
					data-start="500"
					data-easing="easeOutExpo" data-end="8800" data-endspeed="300" data-endeasing="easeInSine">
						JOIN THE COMMUNITY
					</div>

					<div class="caption lfb stl"
					data-x="right"
					data-y="250"
					data-speed="300"
					data-start="500"
					data-easing="easeOutExpo" data-end="8800" data-endspeed="300" data-endeasing="easeInSine" >
						<a href="<?php //echo base_url('about') ?>" class="button_large">Read more</a>
					</div>
                </li> -->
                <li data-transition="cube" data-slotamount="1" data-masterspeed="300"  data-thumb="<?php echo base_url('assets/home/images/thumbs/thumb2.jpg') ?>">
                    <img src="<?php echo base_url('assets/home/images/slides/slide-3.jpg') ?>" alt="">
					<div class="caption very_big_white lfl stl"
					data-x="right"
					data-y="180"
					data-speed="300"
					data-start="500"
					data-easing="easeOutExpo" data-end="8800" data-endspeed="300" data-endeasing="easeInSine">
						DIFFERENT COURSES AVAILABLE
					</div>

					<div class="caption lfr stl"
					data-x="right"
					data-y="250"
					data-speed="300"
					data-start="500"
					data-easing="easeOutExpo" data-end="8800" data-endspeed="300" data-endeasing="easeInSine" >
						<a href="<?php echo base_url('courses') ?>" class="button_large">Read more</a>
					</div>
                </li>
                <li data-transition="slideleft" data-slotamount="1" data-masterspeed="300"  data-thumb="<?php echo base_url('assets/home/images/thumbs/thumb2.jpg') ?>">
                    <img src="<?php echo base_url('assets/home/images/slides/slide-5.jpg') ?>" alt="">
					<div class="caption very_big_white lfl stl"
					data-x="30"
					data-y="180"
					data-speed="300"
					data-start="500"
					data-easing="easeOutExpo" data-end="8800" data-endspeed="300" data-endeasing="easeInSine">
						IMPROVE YOUR SKILLS
					</div>

					<div class="caption big_white lfl stl"
					data-x="30"
					data-y="250"
					data-speed="300"
					data-start="800"
					data-easing="easeOutExpo" data-end="9100" data-endspeed="300" data-endeasing="easeInSine">
						with us
					</div>
                </li>
        	</ul>
        	<div class="tp-bannertimer tp-bottom"></div>
        </div>
    </div>
</section><!--End slider-->

<div class="container">
 	<div class="row" id="main-boxes">
	    <div class="col-md-4 col-sm-4 col-md-offset-4">
	        <div class="box-style-2 green">
	            <a href="<?php echo base_url('courses') ?>" title="All Courses">
	                <img src="<?php echo base_url('assets/home/img/icon-home-course.png') ?>" alt="">
	                <h3>Courses</h3>
	                <p>
						We are providing many courses, so chose a course and learn in very short time.
	                </p>
	            </a>
	        </div>
	    </div>
	    <!--<div class="col-md-4 col-sm-4">
	        <div class="box-style-2 green">
	            <a href="<?php //echo base_url('contact') ?>" title="Apply">
	                <img src="<?php //echo base_url('assets/home/img/icon-home-apply.png') ?>" alt="">
	                <h3>Apply now</h3>
	                <p>
	                	Lorem ipsum dolor sit amet, dicta aliquip ad vix, ne sit everti corpora. Qui cu eros feugiat, elitr iudico ad pri.
	                </p>
	            </a>
	        </div>
	    </div>
	    
	    <div class="col-md-4 col-sm-4">
	        <div class="box-style-2 green">
	            <a href="<?php //echo base_url('contact') ?>" title="Plan a visit">
	                <img src="<?php //echo base_url('assets/home/img/icon-home-visit.png') ?>" alt="">
	                <h3>Plan a visit</h3>
	                <p>
	                	Lorem ipsum dolor sit amet, dicta aliquip ad vix, ne sit everti corpora. Qui cu eros feugiat, elitr iudico ad pri.
	                </p>
	            </a>
	        </div>
	    </div>-->
	</div>
</div> <!-- end container-->
<div class="container">
	<div class="row">
<!-- 		<aside  class="col-md-4 col-sm-4">
		    <div class="box-style-1 ribbon borders">
		        <div class="feat">
		          <i class="icon-group icon-3x"></i>
		          <h3>Expert teachers</h3>
		          <p>
		          	An utinam reprimique duo, putant mandamus cu qui. Autem possim his cu, quodsi nominavi fabellas ut sit, mea ea ullum epicurei. 
		          </p>
		        </div>
		        <hr class="double">
		        <div class="feat">
		          <i class="icon-film icon-3x"></i>
		          <h3>Video Courses</h3>
		          <p>
		          	An utinam reprimique duo, putant mandamus cu qui. Autem possim his cu, quodsi nominavi fabellas ut sit, mea ea ullum epicurei. 
		          </p>
		        </div>
		        
		        <hr class="double">
		        <div class="feat last">
		          <i class="icon-laptop icon-3x"></i>
		          <h3>Online courses</h3>
		          <p>
		          	An utinam reprimique duo, putant mandamus cu qui. Autem possim his cu, quodsi nominavi fabellas ut sit, mea ea ullum epicurei. 
		          </p>
		        </div>
		    </div>
		    <p>
		    	<a  href="<?php echo base_url('all-courses') ?>" title="All courses">
		    		<img src="<?php echo base_url('assets/home/img/banner.jpg') ?>" alt="Banner" class="img-rounded img-responsive" >
		    	</a>
		    </p>
		</aside>
 -->		
 		<section class="col-md-12">
			<div class="col-right">
			    <h2>Welcome on Shakzee</h2>
			    <p>
					Time is money, spend your valuable time from where you get well manner learning in your native language.
					Spending your time on those sites where all programming data are avaialbe but in your native language we are welcome to see you here for encouraging your future.
			    </p>
			    <hr>
			    <div class="row">
			    	<h3 class="text-center">Our Top Courses</h3>
			    	<br><br>
                    		<?php
								/*$course = array(14,3,13);
								$course_home = $this->mod_home->corses_for_nav($course);*/
                    		?>
                    		<?php if($course_home): ?>
                    			<?php foreach($course_home->result() as $course): ?>
		                        	<div class="col-md-4">
										<div class="thumbnail">
											<a href="<?php echo site_url('courses/detail/'.$course->c_id)?>">
										      <img src="<?php echo base_url('assets/images/courses/'.$course->course_cover);?>" alt="<?php echo $course->course_name?>" class="img-responsive">
									    	</a>
									      <div class="caption">
									        <a href="<?php echo site_url('courses/detail/'.$course->c_id)?>">
									        	<h3>
										        	<?php echo $course->course_name?>
										        </h3>
										    </a>
									        <p>	
									        	<?php echo word_limiter($course->course_desc,20,'...')?>
									        </p>
									      </div>
									    </div>		                        		
			                        </div>
		                    <?php endforeach; ?>
							    <p class="text-center">
							    	<a href="<?php echo site_url('courses') ?>" class="button_large">
							    		View all courses 
							    	</a>
							    </p>
	                    <?php else: ?>
	                    	courses not available
	                    <?php endif; ?>
	                    </div><!-- End row -->
	             <hr>
	           <div class="row">
	           		<h3 class="text-center">Start Learning Today with <strong>Shakzee</strong></h3>
	           		<br><br>
		           	<div class="col-md-4">
		           		<div class="fetr">
		           			<img src="<?php echo site_url('assets/images/unlimited-access.png'); ?>" alt="" clas="img-responsive">
			           		<p>
			           			<strong>
				           			Unlimited Access
			           			</strong>
			           		</p>
			           		<p>
			           			learn the advance programming skills with experts support.
			           		</p>
			           	</div>
		           	</div>
		           	<div class="col-md-4">
		           		<div class="fetr">
			           			<img src="<?php echo site_url('assets/images/ex-teachers.png'); ?>" alt="" clas="img-responsive">
			           		<p>
			           			<strong>
				           			Expert Teachers
			           			</strong>
			           		</p>
			           		<p>
			           			We have expert teachers for guidence, those are working in it industry.
			           		</p>
			           	</div>
		           	</div>

		           	<div class="col-md-4">
		           		<div class="fetr">
			           			<img src="<?php echo site_url('assets/images/learn-anywhere.png'); ?>" alt="" clas="img-responsive">
			           		<p>
			           			<strong>
				           			Learn Anywhere
			           			</strong>
			           		</p>
			           		<p>
			           			Having internet, connecting shakzee and learn from anywhere.
			           		</p>
			           	</div>
		           	</div>

	           </div>
	           <?php if($pro_courses->num_rows() > 0 ): ?>
		           <hr>
		           <div class="row">
		           		<h3 class="text-center">Online Courses</h3>
		           		<br>
                    	<?php foreach($pro_courses->result() as $p_course): ?>
		                        	<div class="col-md-4">
										<div class="cnt_09">
											<div class="thumbnail">
												<a href="<?php echo site_url('onlinecourses/detail/'.$p_course->uc_id)?>">
											      <img src="<?php echo base_url('assets/images/p_courses/'.$p_course->uc_cover);?>" alt="<?php echo $p_course->uc_coursename?>" class="img-responsive">
										    	</a>
										      <div class="caption">
										        <a href="<?php echo site_url('onlinecourses/detail/'.$p_course->uc_id)?>">
										        	<h4>
											        	<?php echo $p_course->uc_coursename?>
											        </h4>
											    </a>
											    <div class="">
											    		<?php echo word_limiter(strip_tags($p_course->uc_detail),20,' .... '.anchor('onlinecourses/detail/'.$p_course->uc_id,'Read more'))?>
											    </div>
											    <br>
										        <p>	
										        	Tutor: <strong>
										        		<?php echo $p_course->fname.nbs(1).$p_course->lname; ?>
										        		</strong>
										        </p>
										        	<div class="pprce">
											      	<span>
											      		RS:
											      			<strong>
											      			<?php echo $p_course->uc_fess?>
											      			</strong>
											      	</span>
										     	 </div>
											      <ul class="list-inline">
											      	<li>
													      <p>
													      Duration:
													      	<strong>
													      		<?php echo $p_course->uc_duration?>
													      	</strong>
													      </p>
												     </li>
												     <li>
													      <p>
													      Views:
													      	<strong>
													      		<?php echo pro_course_views($p_course->uc_id);?>
													      	</strong>
													      </p>
													 </li>
													 <li>
													      <p>
													      Level:
													      	<strong>
													      		<?php echo $p_course->uc_level;?>
													      	</strong>
													      </p>
													 </li>
													 <li>
													      <p>
													      Days:
													      	<strong>
													      		<?php echo $p_course->uc_day_from;?>
													      	</strong>
													      	To:
													      	<strong>
													      		<?php echo $p_course->uc_day_to;?>
													      	</strong>
													      </p>
													 </li>
												    </ul>
										      </div>
										    </div>		                        		
										</div>
			                        </div>
		                <?php endforeach; ?>
		                <?php if($pro_courses->num_rows() == 6): ?>
							    <p class="text-center">
							    	<a href="<?php echo site_url('onlinecourses') ?>" class="button_large">
							    		View all 
							    	</a>
							    </p>
		                <?php endif;?>
		           </div>
		       <?php endif;?>
			</div>
		</section>
	</div>
</div><!-- end container-->















