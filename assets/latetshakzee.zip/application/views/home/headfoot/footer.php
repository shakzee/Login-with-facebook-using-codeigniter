
<footer>
<div class="container">
	<div class="row">
    	<div class="col-md-4 col-sm-4" id="quick-links">
        	<h4>Quick links</h4>
	        <ul>
	            <li>
	            	<a href="<?php echo site_url('home')?>" >Home</a>
	            </li>
	            <li>
	            	<a href="<?php echo site_url('courses')?>" >Courses</a>
	            </li>
	            <li>
	            	<a href="<?php echo site_url('contact')?>" >Contactus</a>
	            </li>
	        </ul>
    	</div>
	    <div class="col-md-4 col-sm-4" id="contacts-footer">
	        <h4>Contacts</h4>
	        <ul>
	            <li>
	            	<i class="icon-home"></i> 100 quarters sector 50-D house # 274 near Ghos Pak road korangi karachi.
	            </li>
	            <li>
	            	<i class="icon-phone"></i> Telephone: 
	            	<strong>
	            		+923111848452
	            	</strong>
	            </li>
	            <li>
	            	<i class="icon-envelope"></i> Email: 
		           <strong>
		           	info@shakzee.com
		           </strong>
	            </li>
	        </ul>
	        <hr>
	    </div>
	    <div class="col-md-4 col-sm-4">
<!-- 	        <p>
	        	<img src="<?php echo base_url('assets/home/img/logo-footer.jpg') ?>" alt="">
	        </p>
	        <p>
	        	Copyright © 2016
	        </p>
	        <div class="twitter">
	        	<a href="#" >Follow on Twitter</a>
	        </div>
	        <div class="fb">
	        	<a href="#">Follow on  Facebook</a>
	        </div>  
 -->
 		<div class="nltrs">
	        <h4>Newsletter</h4>
	        <p>
	        	Subscribe to get latest updates.
	        </p>
	        <div id="message-newsletter"></div>
	        <div class="form-group">
            	<input  id="enltr"  type="email" value="" placeholder="Your Email" class="form-control" >
            </div>
            <div class="form-group">
            	<button  id="nltr_2" class="button_medium " style="top:2px; position:relative" data-loading-text="Loading..." class="btn btn-primary" autocomplete="off"> 
            		Subscribe
            	</button>
            </div>
            <div class="form-groups fnlt">
            	
            </div>
 		</div>	   
  	</div>

	</div>
</div>
</footer><!-- End footer-->
<div class="modal fade" id="cmd" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="cmt">Modal title</h4>
      </div>
      <div class="modal-body" id="cmb">

      </div>
      <div class="modal-footer" id="cmf">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div id="toTop">Back to Top</div>


<!-- Jquery -->
<script src="<?php echo base_url('assets/home/js/jquery.js') ?>"></script>
<!-- Support media queries for IE8 -->
<script src="<?php echo base_url('assets/home/js/respond.min.js') ?>"></script>
<script src='<?php echo base_url('assets/snow/dist/snowfall.jquery.min.js')?>'></script>
    <script type='text/javascript'>     
        $(document).ready(function(){
            $('.collectonme').hide();

            //Start the snow default options you can also make it snow in certain elements, etc.
            //$(document).snowfall();
             document.body.className  = "darkBg";
                $('.collectonme').hide();
                $(document).snowfall('clear');
                $(document).snowfall({round : true, minSize: 5, maxSize:8}); // add rounded
            var $testContainer = $('.test-container'),
                testContainerIsSnowing = true;

            $testContainer.snowfall();

            $testContainer.click(function(e){
                testContainerIsSnowing = !testContainerIsSnowing;

                if(!testContainerIsSnowing){
                    $testContainer.snowfall('clear');
                }else{
                    $testContainer.snowfall();
                }
            });

        });
</script>
