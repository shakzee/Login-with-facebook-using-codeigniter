<script src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.8.0/highlight.min.js"></script>
<script src="<?php echo base_url('assets/syntax/highlight.pack.js')?>"></script>
 <script async src="https://static.addtoany.com/menu/page.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
	  $('pre').each(function(i, block) {
	    hljs.highlightBlock(block);
	  });
	});
</script>