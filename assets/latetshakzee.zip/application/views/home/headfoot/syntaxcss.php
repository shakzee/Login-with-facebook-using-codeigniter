<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.8.0/styles/default.min.css">
<link rel="stylesheet" href="<?php echo base_url('assets/syntax/styles/default.css')?>">


